python step-9-ssgsea.gsva-regress-ssgsea.gsva.py \
	--MCI_clinical_infile /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-3-all-eggnog/step-5-DESeq2-1.3fc-0.05p/MCI_vs_Normal/MCI_vs_Normal.Clinical.Info.xls \
	--AD_clinical_infile /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-3-all-eggnog/step-5-DESeq2-1.3fc-0.05p/AD_vs_Normal/AD_vs_Normal.Clinical.Info.xls \
	--ssgsea_geneset_1 step-2-result-gsva_protein.coding_tpm/execution_phase_of_apoptosis-ssgsea-normalize.xls \
	--ssgsea_geneset_2 /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-3-all-eggnog/step-5-DESeq2-1.3fc-0.05p/Conclusion.MCI-AD/SEM_RSEMA-0.06__CFI-0.95-nonfilter/1-Paper-Aβ.Tau_/result-5-lysosome__endosome__golgi__action.potential__pH__GABA__NMDA/1-pH/intracellular.pH.reduction/MCI/step-2-result-gsva_protein.coding_tpm/intracellular.pH.reduction-gsva-normalize.xls 


