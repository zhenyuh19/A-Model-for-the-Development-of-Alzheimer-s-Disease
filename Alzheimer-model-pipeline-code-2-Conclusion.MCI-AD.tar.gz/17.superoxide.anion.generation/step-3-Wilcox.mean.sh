python3 step-3-Wilcox.py \
	--ssGSEA step-2.1-tpm.mean/superoxide.anion.xls \
	--MCI_clinical_info /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-3-all-eggnog/step-5-DESeq2-1.3fc-0.05p/MCI_vs_Normal/MCI_vs_Normal.Clinical.Info.xls \
	--AD_clinical_info /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-3-all-eggnog/step-5-DESeq2-1.3fc-0.05p/AD_vs_Normal/AD_vs_Normal.Clinical.Info.xls 

