python step-2.1-superoxide.anion.generation.plot.py \
	/home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-4-StringTie.prepDE/total_tpm.Symbol.sum.xls \
	superoxide.anion.generation/positive.regulation.of.superoxide.anion.generation.GO.xls \
	superoxide.anion.generation/superoxide.anion.generation.GO.xls \
	/home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-4-tpm.sum.transcript2gene/MCI_vs_Normal/MCI_vs_Normal.Clinical.xls \
	/home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-4-tpm.sum.transcript2gene/AD_vs_Normal/AD_vs_Normal.Clinical.xls \
	step-2.1-tpm.mean/superoxide.anion

