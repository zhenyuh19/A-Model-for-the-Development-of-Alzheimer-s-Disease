python step-4-plot.infile.mk.py \
	step-2-result-ssgsea_protein.coding_tpm/superoxide.anion.generation-ssgsea-normalize.xls  \
	/home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-4-tpm.sum.transcript2gene/MCI_vs_Normal/MCI_vs_Normal.Clinical.xls  \
	/home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-4-tpm.sum.transcript2gene/AD_vs_Normal/AD_vs_Normal.Clinical.xls  \
	step-4-ssgsea.result/superoxide.anion.generation-ssgsea-normalize.plot-infile.xls

