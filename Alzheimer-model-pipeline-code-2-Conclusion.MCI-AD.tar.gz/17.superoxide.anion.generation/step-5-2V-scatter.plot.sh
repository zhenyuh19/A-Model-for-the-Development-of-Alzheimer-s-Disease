Rscript step-5-2V-scatter.plot.R \
	--plot.infile step-4-ssgsea.result/superoxide.anion.generation-ssgsea-normalize.plot-infile.xls \
	--group.name.1  Mitochondrial.Fenton_Iron.Sulfur.Clustering.Synthesis \
	--group.name.2 positive.regulation.of.superoxide.anion.generation \
	--outdir step-5-scatter.plot-result
