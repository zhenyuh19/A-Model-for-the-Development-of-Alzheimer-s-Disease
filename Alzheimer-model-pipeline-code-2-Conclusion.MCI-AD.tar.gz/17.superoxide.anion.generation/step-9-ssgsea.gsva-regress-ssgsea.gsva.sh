python step-9-ssgsea.gsva-regress-ssgsea.gsva.py --MCI_clinical_infile /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-3-all-eggnog/step-5-DESeq2-1.3fc-0.05p/MCI_vs_Normal/MCI_vs_Normal.Clinical.Info.xls --AD_clinical_infile /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-3-all-eggnog/step-5-DESeq2-1.3fc-0.05p/AD_vs_Normal/AD_vs_Normal.Clinical.Info.xls --ssgsea_geneset_2 step-2-result-ssgsea_protein.coding_tpm.UP/superoxide.anion.generation-normalize.xls --ssgsea_geneset_1 ../37.VDAC/step-2-result-ssgsea_protein.coding_tpm/VDAC1-normalize.xls


python step-9-ssgsea.gsva-regress-ssgsea.gsva.py --MCI_clinical_infile /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-3-all-eggnog/step-5-DESeq2-1.3fc-0.05p/MCI_vs_Normal/MCI_vs_Normal.Clinical.Info.xls --AD_clinical_infile /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-3-all-eggnog/step-5-DESeq2-1.3fc-0.05p/AD_vs_Normal/AD_vs_Normal.Clinical.Info.xls --ssgsea_geneset_2 step-2-result-ssgsea_protein.coding_tpm.UP/superoxide.anion.generation-normalize.xls --ssgsea_geneset_1 ../37.VDAC/step-2-result-ssgsea_protein.coding_tpm/VDAC3-normalize.xls


python step-9-ssgsea.gsva-regress-ssgsea.gsva.py --MCI_clinical_infile /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-3-all-eggnog/step-5-DESeq2-1.3fc-0.05p/MCI_vs_Normal/MCI_vs_Normal.Clinical.Info.xls --AD_clinical_infile /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-3-all-eggnog/step-5-DESeq2-1.3fc-0.05p/AD_vs_Normal/AD_vs_Normal.Clinical.Info.xls --ssgsea_geneset_2 step-2-result-ssgsea_protein.coding_tpm.UP/superoxide.anion.generation-normalize.xls --ssgsea_geneset_1 ../37.VDAC/step-2-result-ssgsea_protein.coding_tpm/VDAC-normalize.xls



