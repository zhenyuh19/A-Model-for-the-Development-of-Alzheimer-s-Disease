python step-9-ssgsea.gsva-regress-ssgsea.gsva.py \
	--MCI_clinical_infile /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-3-all-eggnog/step-5-DESeq2-1.3fc-0.05p/MCI_vs_Normal/MCI_vs_Normal.Clinical.Info.xls \
	--AD_clinical_infile /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-3-all-eggnog/step-5-DESeq2-1.3fc-0.05p/AD_vs_Normal/AD_vs_Normal.Clinical.Info.xls \
	--ssgsea_geneset_1 /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-3-all-eggnog/step-5-DESeq2-1.3fc-0.05p/Conclusion.MCI-AD/SEM_RSEMA-0.06__CFI-0.95-nonfilter/1-Paper-Aβ.Tau_/result-5-lysosome__endosome__golgi__action.potential__pH__GABA__NMDA/10.fenton.reation/Mitochondrial.Fenton.reaction__Iron.Sulfur.Clustering.Synthesis.gsva \
	--ssgsea_geneset_2 ./step-2-result-gsva_protein.coding_tpm/protein_targeting_to_lysosome-ssgsea-normalize.xls


python step-9-ssgsea.gsva-regress-ssgsea.gsva.py \
	--MCI_clinical_infile /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-3-all-eggnog/step-5-DESeq2-1.3fc-0.05p/MCI_vs_Normal/MCI_vs_Normal.Clinical.Info.xls \
	--AD_clinical_infile /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-3-all-eggnog/step-5-DESeq2-1.3fc-0.05p/AD_vs_Normal/AD_vs_Normal.Clinical.Info.xls \
	--ssgsea_geneset_1 /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-3-all-eggnog/step-5-DESeq2-1.3fc-0.05p/Conclusion.MCI-AD/SEM_RSEMA-0.06__CFI-0.95-nonfilter/1-Paper-Aβ.Tau_/result-5-lysosome__endosome__golgi__action.potential__pH__GABA__NMDA/10.fenton.reation/Mitochondrial.Fenton.reaction__Iron.Sulfur.Clustering.Synthesis.gsva \
	--ssgsea_geneset_2 ./step-2-result-gsva_protein.coding_tpm/protein_localization_to_lysosome-ssgsea-normalize.xls
