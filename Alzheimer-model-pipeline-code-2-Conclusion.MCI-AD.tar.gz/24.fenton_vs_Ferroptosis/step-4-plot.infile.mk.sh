python step-4-plot.infile.mk.py \
	step-2-result-ssgsea_protein.coding_log_tpm_nonnormal/fenton_vs_Ferroptosis-ssgsea-normalize.xls  \
	/home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-4-tpm.sum.transcript2gene/MCI_vs_Normal/MCI_vs_Normal.Clinical.xls  \
	/home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-4-tpm.sum.transcript2gene/AD_vs_Normal/AD_vs_Normal.Clinical.xls  \
	step-4-ssgsea.result/fenton_vs_Ferroptosis-ssgsea-normalize.plot-infile.xls
