Rscript step-5-2V-scatter.plot.R \
	--plot.infile step-4-ssgsea.result/fenton_vs_Ferroptosis-ssgsea-normalize.plot-infile.xls \
	--group.name.1 fenton  \
	--group.name.2 Ferroptosis \
	--outdir step-5-scatter.plot-result
