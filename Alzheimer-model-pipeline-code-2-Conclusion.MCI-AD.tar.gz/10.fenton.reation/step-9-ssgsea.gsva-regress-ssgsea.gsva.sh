python step-9-ssgsea.gsva-regress-ssgsea.gsva.py \
	--MCI_clinical_infile /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-3-all-eggnog/step-5-DESeq2-1.3fc-0.05p/MCI_vs_Normal/MCI_vs_Normal.Clinical.Info.xls \
	--AD_clinical_infile /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-3-all-eggnog/step-5-DESeq2-1.3fc-0.05p/AD_vs_Normal/AD_vs_Normal.Clinical.Info.xls \
	--ssgsea_geneset_1 Mitochondrial.Fenton.reaction__Iron.Sulfur.Clustering.Synthesis.gsva \
	--ssgsea_geneset_2 /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-3-all-eggnog/step-5-DESeq2-1.3fc-0.05p/Conclusion.MCI-AD/SEM_RSEMA-0.06__CFI-0.95-nonfilter/1-Paper-Aβ.Tau_/result-5-lysosome__endosome__golgi__action.potential__pH__GABA__NMDA/1-pH/transporter/step-2-result-gsva_protein.coding_tpm/acid.extrusion.gsva


python step-9-ssgsea.gsva-regress-ssgsea.gsva.py \
	--MCI_clinical_infile /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-3-all-eggnog/step-5-DESeq2-1.3fc-0.05p/MCI_vs_Normal/MCI_vs_Normal.Clinical.Info.xls \
	--AD_clinical_infile /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-3-all-eggnog/step-5-DESeq2-1.3fc-0.05p/AD_vs_Normal/AD_vs_Normal.Clinical.Info.xls \
	--ssgsea_geneset_1 Mitochondrial.Fenton.reaction__Iron.Sulfur.Clustering.Synthesis.gsva \
	--ssgsea_geneset_2 /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-3-all-eggnog/step-5-DESeq2-1.3fc-0.05p/Conclusion.MCI-AD/SEM_RSEMA-0.06__CFI-0.95-nonfilter/1-Paper-Aβ.Tau_/result-5-lysosome__endosome__golgi__action.potential__pH__GABA__NMDA/1-pH/transporter/step-2-result-gsva_protein.coding_tpm/acid.extrusion.v2.gsva


python step-9-ssgsea.gsva-regress-ssgsea.gsva.py \
	--MCI_clinical_infile /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-3-all-eggnog/step-5-DESeq2-1.3fc-0.05p/MCI_vs_Normal/MCI_vs_Normal.Clinical.Info.xls \
	--AD_clinical_infile /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-3-all-eggnog/step-5-DESeq2-1.3fc-0.05p/AD_vs_Normal/AD_vs_Normal.Clinical.Info.xls \
	--ssgsea_geneset_1 Mitochondrial.Fenton.reaction__Iron.Sulfur.Clustering.Synthesis.gsva \
	--ssgsea_geneset_2 /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-3-all-eggnog/step-5-DESeq2-1.3fc-0.05p/Conclusion.MCI-AD/SEM_RSEMA-0.06__CFI-0.95-nonfilter/1-Paper-Aβ.Tau_/result-5-lysosome__endosome__golgi__action.potential__pH__GABA__NMDA/1-pH/transporter/step-2-result-gsva_protein.coding_tpm/acid.loading.gsva


##### ssgsea
python step-9-ssgsea.gsva-regress-ssgsea.gsva.py \
	--MCI_clinical_infile /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-3-all-eggnog/step-5-DESeq2-1.3fc-0.05p/MCI_vs_Normal/MCI_vs_Normal.Clinical.Info.xls \
	--AD_clinical_infile /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-3-all-eggnog/step-5-DESeq2-1.3fc-0.05p/AD_vs_Normal/AD_vs_Normal.Clinical.Info.xls \
	--ssgsea_geneset_1 Mitochondrial.Fenton.reaction__Iron.Sulfur.Clustering.Synthesis.ssgsea \
	--ssgsea_geneset_2 /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-3-all-eggnog/step-5-DESeq2-1.3fc-0.05p/Conclusion.MCI-AD/SEM_RSEMA-0.06__CFI-0.95-nonfilter/1-Paper-Aβ.Tau_/result-5-lysosome__endosome__golgi__action.potential__pH__GABA__NMDA/1-pH/transporter/step-2-result-ssgsea_protein.coding_tpm/acid.extrusion.ssgsea


python step-9-ssgsea.gsva-regress-ssgsea.gsva.py \
	--MCI_clinical_infile /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-3-all-eggnog/step-5-DESeq2-1.3fc-0.05p/MCI_vs_Normal/MCI_vs_Normal.Clinical.Info.xls \
	--AD_clinical_infile /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-3-all-eggnog/step-5-DESeq2-1.3fc-0.05p/AD_vs_Normal/AD_vs_Normal.Clinical.Info.xls \
	--ssgsea_geneset_1 Mitochondrial.Fenton.reaction__Iron.Sulfur.Clustering.Synthesis.ssgsea \
	--ssgsea_geneset_2 /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-3-all-eggnog/step-5-DESeq2-1.3fc-0.05p/Conclusion.MCI-AD/SEM_RSEMA-0.06__CFI-0.95-nonfilter/1-Paper-Aβ.Tau_/result-5-lysosome__endosome__golgi__action.potential__pH__GABA__NMDA/1-pH/transporter/step-2-result-ssgsea_protein.coding_tpm/acid.extrusion.v2.ssgsea


python step-9-ssgsea.gsva-regress-ssgsea.gsva.py \
	--MCI_clinical_infile /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-3-all-eggnog/step-5-DESeq2-1.3fc-0.05p/MCI_vs_Normal/MCI_vs_Normal.Clinical.Info.xls \
	--AD_clinical_infile /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-3-all-eggnog/step-5-DESeq2-1.3fc-0.05p/AD_vs_Normal/AD_vs_Normal.Clinical.Info.xls \
	--ssgsea_geneset_1 Mitochondrial.Fenton.reaction__Iron.Sulfur.Clustering.Synthesis.ssgsea \
	--ssgsea_geneset_2 /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-3-all-eggnog/step-5-DESeq2-1.3fc-0.05p/Conclusion.MCI-AD/SEM_RSEMA-0.06__CFI-0.95-nonfilter/1-Paper-Aβ.Tau_/result-5-lysosome__endosome__golgi__action.potential__pH__GABA__NMDA/1-pH/transporter/step-2-result-ssgsea_protein.coding_tpm/acid.loading.ssgsea


python step-9-ssgsea.gsva-regress-ssgsea.gsva.py \
	--MCI_clinical_infile /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-3-all-eggnog/step-5-DESeq2-1.3fc-0.05p/MCI_vs_Normal/MCI_vs_Normal.Clinical.Info.xls --AD_clinical_infile /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-3-all-eggnog/step-5-DESeq2-1.3fc-0.05p/AD_vs_Normal/AD_vs_Normal.Clinical.Info.xls --ssgsea_geneset_1 Mitochondrial.Fenton.reaction__Iron.Sulfur.Clustering.Synthesis.ssgsea --ssgsea_geneset_2 /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-3-all-eggnog/step-5-DESeq2-1.3fc-0.05p/Conclusion.MCI-AD/SEM_RSEMA-0.06__CFI-0.95-nonfilter/1-Paper-Aβ.Tau_/result-5-lysosome__endosome__golgi__action.potential__pH__GABA__NMDA/23.mitochondrial.protein.catabolic.process/step-2-result-ssgsea_protein.coding_tpm/UCP5-ssgsea-normalize.xls


python step-9-ssgsea.gsva-regress-ssgsea.gsva.py --MCI_clinical_infile /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-3-all-eggnog/step-5-DESeq2-1.3fc-0.05p/MCI_vs_Normal/MCI_vs_Normal.Clinical.Info.xls --AD_clinical_infile /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-3-all-eggnog/step-5-DESeq2-1.3fc-0.05p/AD_vs_Normal/AD_vs_Normal.Clinical.Info.xls --ssgsea_geneset_1 step-2.1-tpm.mean/Mitochondrial.Fenton.reaction__Mitochondrial.Iron.Sulfur.Clustering.Synthesis.xls --ssgsea_geneset_2 /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-3-all-eggnog/step-5-DESeq2-1.3fc-0.05p/Conclusion.MCI-AD/SEM_RSEMA-0.06__CFI-0.95-nonfilter/1-Paper-Aβ.Tau_/result-5-lysosome__endosome__golgi__action.potential__pH__GABA__NMDA/14.ubiquitin-proteasome/step-2-result-ssgsea_protein.coding_log_tpm_nonnormal/ubiquitin-proteasome-ssgsea-normalize.xls

