python step-1-make.ssgsea.geneset.py \
	--DESeq2 /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-3-all-eggnog/step-5-DESeq2-1.3fc-0.05p/MCI_vs_Normal/MCI_vs_Normal.transcript.2.Gene.DESeq2.results.xls.xls \
	--GO_indir . \
	--transcript_2_gene_infile /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-3-all-eggnog/step-5-DESeq2-1.3fc-0.05p/MCI-2-AD__transcript-2-Symbol.xls

cat */*ssgsea.genesets.Sign.xls > fenton.ssgsea.genesets.Sign.xls

cat */*ssgsea.genesets.xls > fenton.ssgsea.genesets.xls

cat */*ssgsea.genesets.Symbol.xls > fenton.ssgsea.genesets.Symbol.xls

cat */*ssgsea.genesets.Sign.UP.xls > fenton.ssgsea.genesets.Sign.UP.xls

