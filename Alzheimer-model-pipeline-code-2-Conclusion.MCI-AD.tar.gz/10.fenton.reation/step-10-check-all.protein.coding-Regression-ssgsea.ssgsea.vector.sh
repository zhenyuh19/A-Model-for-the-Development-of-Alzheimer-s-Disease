python step-10-check-all.protein.coding-Regression-ssgsea.gsva.vector.py \
	--tpm /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-3-all-eggnog/step-5-DESeq2-1.3fc-0.05p/total_Protein.Coding_tpm.xls \
	--MCI_clinical_infile  /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-3-all-eggnog/step-5-DESeq2-1.3fc-0.05p/MCI_vs_Normal/MCI_vs_Normal.Clinical.Info.xls \
	--AD_clinical_infile  /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-3-all-eggnog/step-5-DESeq2-1.3fc-0.05p/AD_vs_Normal/AD_vs_Normal.Clinical.Info.xls \
	--MCI_DGT_infile /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-3-all-eggnog/step-5-DESeq2-1.3fc-0.05p/MCI_vs_Normal/MCI_vs_Normal.transcript2gene.DESeq2.SignificanceDiff.coding.UP.DOWN.xls \
	--AD_DGT_infile /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-3-all-eggnog/step-5-DESeq2-1.3fc-0.05p/AD_vs_Normal/AD_vs_Normal.transcript2gene.DESeq2.SignificanceDiff.coding.UP.DOWN.xls \
	--ssgsea_gsva Mitochondrial.Fenton.reaction__Iron.Sulfur.Clustering.Synthesis.ssgsea \
	--output step-10-Mitochondrial.Fenton.reaction__Iron.Sulfur.Clustering.Synthesis.ssgsea-resgress-all.Transcripts
