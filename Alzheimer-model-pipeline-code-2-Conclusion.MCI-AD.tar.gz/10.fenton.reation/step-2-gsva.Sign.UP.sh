Rscript ssGSEA.R \
	--tpm /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-3-all-eggnog/step-5-DESeq2-1.3fc-0.05p/total_Protein.Coding_tpm.xls \
	--gmt /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-3-all-eggnog/step-5-DESeq2-1.3fc-0.05p/Conclusion.MCI-AD/SEM_RSEMA-0.06__CFI-0.95-nonfilter/1-Paper-Aβ.Tau_/result-5-lysosome__endosome__golgi__action.potential__pH__GABA__NMDA/10.fenton.reation/fenton.ssgsea.genesets.Sign.UP.xls \
	--outdir step-2-result-gsva_protein.coding_tpm.UP \
	--prefix fenton \
	--method gsva
