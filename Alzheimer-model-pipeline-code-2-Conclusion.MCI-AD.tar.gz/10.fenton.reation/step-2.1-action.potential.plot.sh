python step-2.1-action.potential.plot.py \
	/home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-4-StringTie.prepDE/total_tpm.Symbol.sum.xls \
	./Mitochondrial.Fenton.reaction/Mitochondrial.Fenton.reaction__Mitochondrial.Iron.Sulfur.Clustering.Synthesis.Genes-GO.xls \
	./Mitochondrial.Fenton.reaction/Mitochondrial.Fenton.reaction__Mitochondrial.Iron.Sulfur.Clustering.Synthesis.Genes-GO.xls \
	/home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-4-tpm.sum.transcript2gene/MCI_vs_Normal/MCI_vs_Normal.Clinical.xls \
	/home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-4-tpm.sum.transcript2gene/AD_vs_Normal/AD_vs_Normal.Clinical.xls \
	step-2.1-tpm.mean/Mitochondrial.Fenton.reaction__Mitochondrial.Iron.Sulfur.Clustering.Synthesis

