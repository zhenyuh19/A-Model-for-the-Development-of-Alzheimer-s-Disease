python3 step-3-Wilcox.py \
	--ssGSEA step-2-result-ssgsea_protein.coding_tpm/Tau-ssgsea-normalize.xls \
	--MCI_clinical_info conditions_rowsnames.txt

