python step-9-ssgsea.gsva-regress-ssgsea.gsva.py \
	--MCI_clinical_infile /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-3-all-eggnog/step-5-DESeq2-1.3fc-0.05p/MCI_vs_Normal/MCI_vs_Normal.Clinical.Info.xls \
	--AD_clinical_infile /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-3-all-eggnog/step-5-DESeq2-1.3fc-0.05p/AD_vs_Normal/AD_vs_Normal.Clinical.Info.xls \
	--ssgsea_geneset_2 ../44-Fenton.reaction.Level/step-2-result-gsva_protein.coding_tpm/Fenton.reaction.Level_Fe_hydroxyl.radical_hydrogen.peroxide_superoxide.anion-normalize.xls \
	--ssgsea_geneset_1 step-2-result-ssgsea_protein.coding_tpm/
