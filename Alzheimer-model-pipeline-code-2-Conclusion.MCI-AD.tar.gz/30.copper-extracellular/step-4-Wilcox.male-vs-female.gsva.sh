python3 step-4-Wilcox.male-vs-female.py \
	--ssGSEA step-2-result-gsva_protein.coding_tpm/copper-gsva-normalize.xls \
	--MCI_male_clinical_info /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-3-all-eggnog/step-5-DESeq2-1.3fc-0.05p/MCI_vs_Normal/Male/MCI_vs_Normal.male.Clinical.Info.xls \
	--AD_male_clinical_info  /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-3-all-eggnog/step-5-DESeq2-1.3fc-0.05p/AD_vs_Normal/Male/AD_vs_Normal.male.Clinical.Info.xls \
	--MCI_female_clinical_info /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-3-all-eggnog/step-5-DESeq2-1.3fc-0.05p/MCI_vs_Normal/Female/MCI_vs_Normal.female.Clinical.Info.xls \
	--AD_female_clinical_info /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-3-all-eggnog/step-5-DESeq2-1.3fc-0.05p/AD_vs_Normal/Female/AD_vs_Normal.female.Clinical.Info.xls

