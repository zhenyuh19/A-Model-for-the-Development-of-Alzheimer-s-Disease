python3 step-4-get.up.single.geneset.py \
	--ssGSEA  /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-3-all-eggnog/step-5-DESeq2-1.3fc-0.05p/Conclusion.MCI-AD/SEM_RSEMA-0.06__CFI-0.95-nonfilter/1-Paper-Aβ.Tau_/result-5-lysosome__endosome__golgi__action.potential__pH__GABA__NMDA/32.extracellular.acidosis_UP/step-2-result-ssgsea_protein.coding_tpm/ASIC-ssgsea-normalize.xls \
	--MCI_clinical_info /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-3-all-eggnog/step-5-DESeq2-1.3fc-0.05p/MCI_vs_Normal/MCI_vs_Normal.Clinical.Info.xls \
	--AD_clinical_info /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-3-all-eggnog/step-5-DESeq2-1.3fc-0.05p/AD_vs_Normal/AD_vs_Normal.Clinical.Info.xls \
	--output . \
	--gmt ASIC.ssgsea.genesets.xls \
	--prefix ASIC.single.gene-UP
