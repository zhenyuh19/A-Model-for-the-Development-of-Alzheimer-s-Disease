python step-2.1-hydrogen.peroxide.plot.py \
	/home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-4-StringTie.prepDE/total_tpm.Symbol.sum.xls \
	hydrogen.peroxide/hydrogen.peroxide.biosynthetic.process.GO.xls \
	hydrogen.peroxide/hydrogen.peroxide.catabolic.process.GO.xls \
	/home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-4-tpm.sum.transcript2gene/MCI_vs_Normal/MCI_vs_Normal.Clinical.xls \
	/home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-4-tpm.sum.transcript2gene/AD_vs_Normal/AD_vs_Normal.Clinical.xls \
	step-2.1-tpm.mean/hydrogen.peroxide


python step-2.1-hydrogen.peroxide.plot.py \
	/home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-4-StringTie.prepDE/total_tpm.Symbol.sum.xls \
	hydrogen.peroxide/SOD2.GO.xls \
	hydrogen.peroxide/hydrogen.peroxide.catabolic.process.GO.xls \
	/home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-4-tpm.sum.transcript2gene/MCI_vs_Normal/MCI_vs_Normal.Clinical.xls \
	/home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-4-tpm.sum.transcript2gene/AD_vs_Normal/AD_vs_Normal.Clinical.xls \
	step-2.1-tpm.mean/SOD2

