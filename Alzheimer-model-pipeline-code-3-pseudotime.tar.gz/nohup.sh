python nohup.py --indir /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-6-pseudotime-FR-vs-7events/step-1-ss-MCI-DESeq/

python nohup.py --indir /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-6-pseudotime-FR-vs-7events/step-1-ss-AD-DESeq/
