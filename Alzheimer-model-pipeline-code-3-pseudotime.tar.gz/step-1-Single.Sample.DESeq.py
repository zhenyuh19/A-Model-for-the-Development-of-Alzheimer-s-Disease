#!/python
#-*-coding:utf-8-*-
# 检查转录本(不提供表达量矩阵) 和 指定通路的回归关系 

def ss_DESeq():
	'''
	 
	'''
	import re,getopt,os,sys,optparse,glob,copy
	import pandas as pd
	from sklearn.decomposition import PCA	
	from statsmodels.formula.api import ols

	# [ read cmd by optparse modules ]
	usage="usage:python2 %prog [-options1 arg1] [-options2 arg2] ..."
	parser=optparse.OptionParser(usage,version="%prog 1.2")

	# input/output dir or file
	parser.add_option('--output', dest = 'output', type = 'string', help = 'the position of the result')
	parser.add_option('--prefix', dest = 'prefix', type = 'string', help = '')
	parser.add_option('--tpm', dest = 'tpm', type = 'string', help = '')
	parser.add_option('--clinical', dest = 'clinical', type = 'string', help = '')
	parser.add_option('--count', dest = 'count', type = 'string', help = '')
	parser.add_option('--MCI_AD', dest = 'MCI_AD', type = 'string', help = '')
	parser.add_option('--indir', dest = 'indir', type = 'string', help = '')
	parser.add_option('--tumor_name', dest = 'tumor_name', type = 'string', help = '')

	# oject the cmd
	(options,args) = parser.parse_args()

	# [public]
	output = options.output
	tpm = options.tpm
	clinical = options.clinical
	prefix = options.prefix
	count = options.count
	MCI_AD = options.MCI_AD
	indir = options.indir
	tumor_name = options.tumor_name

	if output:
		makedir_return = os.path.isdir(output) or os.makedirs(output)
	
	if tpm:
		tpm_df = pd.read_csv(tpm, sep = "\t", index_col = "Gene")
	if count:
		count_df = pd.read_csv(count, sep = "\t", index_col = "transcript_id")

	def DESeq2(exp_matrix, sample_clinical, output, tumor_name, group1, group2):
		shell = '''Rscript  /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-6-pseudotime-FR-vs-7events/noBatch.DESeq2.R \\
	--exp.matrix {_exp_matrix} \\
	--sampleinfo.matrix {_sample_clinical} \\
	--outdir {_output} \\
	--prefix {_tumor_name} \\
	--group.1 {_group1} \\
	--group.2 {_group2}
'''.format(_exp_matrix = exp_matrix, _sample_clinical = sample_clinical, _output = output, _tumor_name = tumor_name, _group1 = group1, _group2 = group2)

		return shell

	clinical_df = pd.read_csv(clinical, sep = "\t", index_col = "specimenID")
	normal_samples = clinical_df[clinical_df['sample_type'] == "Normal"].index.tolist()

	if MCI_AD == "MCI":
		case_samples = clinical_df[clinical_df['sample_type'] == "MCI"].index.tolist()
	if MCI_AD == "AD":
		case_samples = clinical_df[clinical_df['sample_type'] == "AD"].index.tolist()
#	block_df = pd.read_csv(block, index_col = "transcript", sep = "\t")	
#	block_df = block_df.loc[count_df.index.tolist()]
#	block_df = block_df['Gene.Length']
#	gene_length_outfile = output + "/StringTie.gene.length.xls"
#	block_df.to_csv(gene_length_outfile, sep = "\t", index_label = "Gene")
	DESeq_outdir = output
	makedir_return = os.path.isdir(DESeq_outdir) or os.makedirs(DESeq_outdir)
	i = 0
	for ss in case_samples:
		if not os.path.isfile(DESeq_outdir + "/" + ss + ".DESeq.sh.e"):
			ssCase_Normal = [ss] + normal_samples
			ssCase_Normal_count_df = count_df[ssCase_Normal]
			ssCase_Normal_outfile = DESeq_outdir + "/" + ss + ".count.xls"
			ssCase_Normal_count_df.to_csv(ssCase_Normal_outfile, sep = "\t", index_label = "Gene")

			clinical_df = pd.DataFrame()
			clinical_df['samples'] = ssCase_Normal
			clinical_df['sample_type'] = [MCI_AD] + ['Normal'] * len(normal_samples)
			clinical_infile = DESeq_outdir + "/" + ss + ".clinical.xls"
			clinical_df.to_csv(clinical_infile, sep = ",", index = False)

			DESeq2_shell = DESeq2(exp_matrix = ssCase_Normal_outfile, sample_clinical = clinical_infile, output = DESeq_outdir, tumor_name = ss, group1 = MCI_AD, group2 = "Normal")
			DESeq_outshell = DESeq_outdir + "/" + ss + ".DESeq.sh"
			with open(DESeq_outshell, "w") as OUT:
				OUT.write(DESeq2_shell)

			if i < 50:
				i += 1
				os.system("nohup sh {_DESeq_outshell} > {_DESeq_outshell}.o 2 > {_DESeq_outshell}.e &".format(_DESeq_outshell = DESeq_outshell))
		else:
			print(ss)
				


if __name__ == '__main__':
	'''
	'''	
	
	ss_DESeq()




	
