python3  step-1-Single.Sample.edgeR.normal.py \
	--block /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-2-DPFC-StringTie-merge/DPFC-stringtie_merged.block \
	--count /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-3-all-eggnog/step-5-DESeq2-1.3fc-0.05p/AD_vs_Normal/AD_vs_Normal.transcript.stringtie.Count.xls \
	--clinical /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-3-all-eggnog/step-5-DESeq2-1.3fc-0.05p/AD_vs_Normal/AD_vs_Normal.Clinical.Info.xls \
	--output /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-6-pseudotime/step-1-ss-Normal
