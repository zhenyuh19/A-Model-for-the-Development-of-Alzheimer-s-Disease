# author : joefish
# version: v1
# modify_date : 20191119
# document: 此脚本的 batch 移除用的 RUVg 的办法, 引入 house keeping 基因进行标准化, 为避免 house keeping 基因也是差异基因，需要进行过滤

library("optparse")
# 命令行选项
option_list = list(
	make_option(c("-f", "--exp.matrix"), type = "character", default = NULL, help = "表达量矩阵文件名 [default = %default]", metavar = "character"),
	make_option(c("-s", "--sampleinfo.matrix"), type = "character", default = "NULL", help = "样本信息矩阵文件名 [default = %default]", metavar = "character"),
	make_option(c("-g", "--house.keeping.gene"), type = "character", default = NULL, help = "House Keeping 基因 [default = %default]", metavar = "character"),
	make_option(c("-x", "--group.1"), type = "character", default = NULL, help = "组 1 名 [default = %default]", metavar = "character"),
	make_option(c("-y", "--group.2"), type = "character", default = NULL, help = "组 2 名 [default = %default]", metavar = "character"),
	make_option(c("-p", "--prefix"), type = "character", default = "NULL", help = "所有输出文件的相同前缀名 [default = %default]", metavar = "character"),
	make_option(c("-o", "--outdir"), type ="character", default = ".", help = "输出目录 [default= %default]", metavar = "character")
);
opt_parser = OptionParser(option_list=option_list)
opt = parse_args(opt_parser)

library('DESeq2')
library("RColorBrewer")
#library("gplots")
#library("amap")
#library("ggplot2")
#library('pheatmap')
#library('sva')
library("RUVSeq")

# 录入数据
readscount_df <- read.table(opt$exp.matrix, header = TRUE, stringsAsFactors = TRUE, sep = "\t", row.names = "Gene", check.names = F)
readscount_df <- round(readscount_df)	# 四舍五入
sampleInfo <- read.table(opt$sampleinfo.matrix, header = T, row.names = 1, com = '', quote = '', check.names = F, sep = ",", colClasses = "factor")
#gene_block <- read.table(ops[3], sep = "\t", header = TRUE)
group.1 <- opt$group.1
group.2 <- opt$group.2
outdir <- opt$outdir
prefix <- opt$prefix

# 初过滤
readscount_df <- readscount_df[rowSums(readscount_df) > 1, ]		# 每个基因所有样本的 reads 至少是 1 个

# 样本信息因子化
sample_rowname <- row.names(sampleInfo)
sample <- data.frame(lapply(sampleInfo, function(x) factor(x, levels = unique(x))))
rownames(sample) <- sample_rowname

# 初步差异分析，获取标准化结果
sampleA = group.1
sampleB = group.2
contrastV <- c("sample_type", sampleA, sampleB)
ddsFullCountTable <- DESeqDataSetFromMatrix(countData = readscount_df, colData = sample,  design =~ sample_type)
dds.batch <- DESeq(ddsFullCountTable)
dds.no.batch <- dds.batch
res.batch <- results(dds.batch,  contrast = contrastV) # results函数提取差异基因分析结果，包含log2 fold changes, p values和adjusted p values
res <- res.batch
#sig.gene.batch <- rownames(res.batch)[which(res.batch$pvalue <= .05)]	# 暂时不考虑 foldchange

# batch 评估
#ddsruv <- dds.batch
#set <- newSeqExpressionSet(counts(dds.batch))
#idx <- rowSums(counts(set) > 1) >= 2	# 每行
#set <- set[idx, ]
#set <- betweenLaneNormalization(set, which = "upper")
#house.keeping.gene.df <- read.table(opt$house.keeping.gene, header = T, row.names = 1, com = '', quote = '', check.names = F, sep = "\t", colClasses = "factor")
#HK.gene <- rownames(house.keeping.gene.df)
#empirical <- rownames(set)[ rownames(set) %in% HK.gene ]	# 确保 HK基因在 set 数据集里
#empirical <- setdiff(HK.gene, sig.gene.batch)				# 确保 HK基因在 set 数据集里, 且不能是差异基因
#empirical <- intersect(rownames(set), empirical)
#setRUVg <- RUVg(set, empirical, k = 1)						# k=3, 如测序平台、reads长度、测序中心
#ddsruv$W1 <- setRUVg$W_1
#ddsruv$W2 <- setRUVg$W_2
#ddsruv$W3 <- setRUVg$W_3
#design(ddsruv) <- ~ W1 + W2 + W3 + tissue
#design(ddsruv) <- ~ W1 + tissue

# 差异基因重分析
#dds.no.batch <- DESeq(ddsruv, test = 'LRT', reduced =~ W1 + W2 + W3)
#dds.no.batch <- DESeq(ddsruv, test = 'LRT', reduced =~ W1)
#res <- results(dds.no.batch,  contrast = contrastV) # results函数提取差异基因分析结果，包含log2 fold changes, p values和adjusted p values

# 返回标准化的数据
#normalized_counts <- counts(dds.no.batch, normalized = TRUE)

# 根据基因在不同的样本中表达变化的差异程度mad值对数据排序，差异越大的基因排位越前
#normalized_counts_mad <- apply(normalized_counts, 1, mad)
#normalized_counts <- normalized_counts[order(normalized_counts_mad, decreasing = T), ]

# 标准化后的数据输出
#normalized.file <- paste(c(prefix, ".DESeq2.normalized.xls"), collapse = "")
#normalized.file <- paste(outdir, normalized.file, sep = "/", collapse = "")
#write.table(normalized_counts, file = normalized.file, quote = F, sep = "\t", row.names = T, col.names = T)
#system(paste("sed -i '1 s/^/Gene\t/'", normalized.file))

# log / vst 转换
#if(nrow(sampleInfo) < 30){
#	normal.DESeq2 <- rlog(dds.no.batch, blind = FALSE)
#}else{
#	normal.DESeq2 <- vst(dds.no.batch, blind = FALSE)	# > 30个样本，用vst加速转换，且对高表达的基因不敏感
#}

#rlogMat <- assay(normal.DESeq2)
#rlogMat <- rlogMat[order(normalized_counts_mad, decreasing = T), ]
#normalized.rlog.file <- paste(c(prefix, ".DESeq2.normalized.rlog.xls"), collapse = "")
#normalized.rlog.file <- paste(outdir, normalized.rlog.file, sep = "/", collapse = "")
#write.table(rlogMat, file = normalized.rlog.file, quote = F, sep = "\t", row.names = T, col.names = T)
#system(paste("sed -i '1 s/^/Gene\t/'", normalized.rlog.file))

# 给DESeq2的原始输出结果增加样品平均表达信息，使得结果更容易理解和解析
# 获得第一组数据均值
baseA <- counts(dds.no.batch, normalized = TRUE)[, colData(dds.no.batch)$sample_type == sampleA]
if (is.vector(baseA)){
    baseMeanA <- as.data.frame(baseA)
} else {
    baseMeanA <- as.data.frame(rowMeans(baseA))
}
colnames(baseMeanA) <- sampleA

# 获得第二组数据均值
baseB <- counts(dds.no.batch, normalized = TRUE)[, colData(dds.no.batch)$sample_type == sampleB]
if (is.vector(baseB)){
        baseMeanB <- as.data.frame(baseB)
} else {
        baseMeanB <- as.data.frame(rowMeans(baseB))
}
colnames(baseMeanB) <- sampleB

# 结果组合
res <- results(dds.no.batch,  contrast = contrastV)
res <- cbind(baseMeanA, baseMeanB, as.data.frame(res))
# 校正后p-value为NA的复制为1
res$padj[is.na(res$padj)] <- 1
# 按pvalue排序, 把差异大的基因放前面
res <- res[order(res$pvalue), ]
#整体分析结果输出到文件
comp <- paste(sampleA, "vs", sampleB, sep = "_")
# 生成文件名
file_base <- paste(prefix, comp, "DESeq2", sep = ".", collapse = "")
file_base1 <- paste(file_base, "results.xls", sep = ".", collapse = "")
file_base1 <- paste(outdir, file_base1, sep = "/", collapse = "")
write.table(as.data.frame(res), file = file_base1, sep = "\t", quote = F, row.names = T)
system(paste("sed -i '1 s/^/Gene\t/'", file_base1))
