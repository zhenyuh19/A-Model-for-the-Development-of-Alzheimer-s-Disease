#!/python
#-*-coding:utf-8-*-
# 统计

def Wilcox():
	'''
	 
	'''
	import re,getopt,os,sys,optparse,glob,itertools
	import pandas as pd
	import scipy
	import scipy.stats as stats
	import statsmodels.api as sm
	import numpy as np

	# [ read cmd by optparse modules ]
	usage="usage:python2 %prog [-options1 arg1] [-options2 arg2] ..."
	parser=optparse.OptionParser(usage,version="%prog 1.2")

	# input/output dir or file
	parser.add_option('--extracellular_acidosis_MCI_LFR_7Events', dest = 'extracellular_acidosis_MCI_LFR_7Events', type = 'string', help = '')
	parser.add_option('--MCI_LFR_7Events', dest = 'MCI_LFR_7Events', type = 'string', help = '')
	parser.add_option('--AD_LFR_7Events', dest = 'AD_LFR_7Events', type = 'string', help = '')
	parser.add_option('--MCI_clinical_info', dest = 'MCI_clinical_info', type = 'string', help = '')
	parser.add_option('--AD_clinical_info', dest = 'AD_clinical_info', type = 'string', help = '')
	parser.add_option('--clinical_info', dest = 'clinical_info', type = 'string', help = '')
	parser.add_option('--output', dest = 'output', type = 'string', help = 'the position of the result')
	parser.add_option('--prefix', dest = 'prefix', type = 'string', help = '')
	parser.add_option('--Pseudotime', dest = 'Pseudotime', type = 'string', help = '')
	parser.add_option('--apoto_label', dest = 'apoto_label', type = 'string', help = '')

	# oject the cmd
	(options,args) = parser.parse_args()

	# [public]
	extracellular_acidosis_MCI_LFR_7Events = options.extracellular_acidosis_MCI_LFR_7Events
	MCI_LFR_7Events = options.MCI_LFR_7Events
	AD_LFR_7Events = options.AD_LFR_7Events
	MCI_clinical_info = options.MCI_clinical_info
	AD_clinical_info = options.AD_clinical_info
	clinical_info = options.clinical_info
	output = options.output
	prefix = options.prefix
	Pseudotime = options.Pseudotime
	apoto_label = options.apoto_label

	# 读取包含时间序列信息的文件
	time_series_data = pd.read_csv(Pseudotime, sep = "\t", index_col = "Sample")
	
	# 读取包含9列信息的文件
	MCI_score_data = pd.read_csv(MCI_LFR_7Events, index_col = "Sample", sep = "\t")
	AD_score_data = pd.read_csv(AD_LFR_7Events, index_col = "Sample", sep = "\t")
	AD_score_data = AD_score_data[MCI_score_data.columns]
	score_data = MCI_score_data.append(AD_score_data)
	score_data = score_data.loc[time_series_data.index]

	# 设定bin的大小和步长
	bin_size = 40
	step_size = 10
	
	# 初始化一个DataFrame来存储结果
	results = pd.DataFrame(columns=['bin', "transporters", "GLS", "UCP", "Tau_formation", "Intracellular_pH_elevation", "Endosomal_pH", "Lysosomal_pH"])

	# 滑动窗口创建每个bin
	for bin_start in range(0, len(time_series_data), step_size):
		bin_end = bin_start + bin_size
	
		if bin_end > len(time_series_data):
			break
	
		print(bin_start, " - ", bin_end)
		bin_group = time_series_data.iloc[bin_start:bin_end]
#		print(bin_group)
		X = score_data.loc[bin_group.index, ["transporters", "GLS", "UCP", "Tau_formation", "Intracellular_pH_elevation", "Endosomal_pH", "Lysosomal_pH"]]
#		print(X)	
		y = score_data.loc[bin_group.index, ['LFR']]
#		print(y)	

		# 进行多元回归分析
#		X = sm.add_constant(X)  # 添加截距项
		model = sm.OLS(y, X).fit()
	
		# 提取回归系数和P值
		coefficients = model.params
		print(coefficients)
		p_values = model.pvalues
		print(p_values)

		# 计算贡献值
		contribution = coefficients * -np.log10(p_values)
	
		# 将结果添加到结果DataFrame中
		result_row = [bin_start] + contribution.tolist()
		print(result_row)
#		result_row = [bin_start] + contribution.tolist()
		results = results.append(pd.Series(result_row, index=results.columns), ignore_index=True)

	# 将结果保存到CSV文件
	results.to_csv('contributions.1.csv', index = False, sep = "\t")
	

if __name__ == '__main__':
	'''
	'''	
	
	Wilcox()

