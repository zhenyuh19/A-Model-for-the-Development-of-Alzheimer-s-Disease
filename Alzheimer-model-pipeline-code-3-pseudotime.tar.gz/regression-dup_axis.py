#!/python
#-*-coding:utf-8-*-
# 检查转录本(不提供表达量矩阵) 和 指定通路的回归关系 

def ss_DESeq():
	'''
	 
	'''
	import re,getopt,os,sys,optparse,glob,copy
	import pandas as pd
	from sklearn.decomposition import PCA	
	from statsmodels.formula.api import ols

	# [ read cmd by optparse modules ]
	usage="usage:python2 %prog [-options1 arg1] [-options2 arg2] ..."
	parser=optparse.OptionParser(usage,version="%prog 1.2")

	# input/output dir or file
	parser.add_option('--output', dest = 'output', type = 'string', help = 'the position of the result')
	parser.add_option('--prefix', dest = 'prefix', type = 'string', help = '')
	parser.add_option('--tpm', dest = 'tpm', type = 'string', help = '')
	parser.add_option('--clinical', dest = 'clinical', type = 'string', help = '')
	parser.add_option('--count', dest = 'count', type = 'string', help = '')
	parser.add_option('--MCI_AD', dest = 'MCI_AD', type = 'string', help = '')
	parser.add_option('--indir', dest = 'indir', type = 'string', help = '')
	parser.add_option('--tumor_name', dest = 'tumor_name', type = 'string', help = '')

	# oject the cmd
	(options,args) = parser.parse_args()

	# [public]
	output = options.output
	tpm = options.tpm
	clinical = options.clinical
	prefix = options.prefix
	count = options.count
	MCI_AD = options.MCI_AD
	indir = options.indir
	tumor_name = options.tumor_name

	if output:
		makedir_return = os.path.isdir(output) or os.makedirs(output)
	
	for par, dir_lst, file_lst in os.walk(indir):
		for subfile in file_lst:
			if re.search(r"-Amyloid-2Events.xls$", subfile):
				subfile_absfile = par + "/" + subfile
				basename = subfile.split(".xls")[0]
				os.system("Rscript /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-6-pseudotime-FR-vs-7events/regression-dup_axis.R --infile {_subfile} --outdir /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-6-pseudotime-FR-vs-7events/step-4-rank/ --prefix {_prefix}".format(_subfile = subfile_absfile, _prefix = basename))

	


if __name__ == '__main__':
	'''
	'''	
	
	ss_DESeq()




	
