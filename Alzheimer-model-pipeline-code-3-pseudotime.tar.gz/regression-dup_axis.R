library("optparse")
# 命令行选项
option_list = list(
	make_option(c("-i", "--infile"), type = "character", default = NULL, help = "表达量文件名 [default = %default]", metavar = "character"),
	make_option(c("-d", "--gmt"), type = "character", default = NULL, help = "ssgsea 数据库 [default = %default]", metavar = "character"),
	make_option(c("-o", "--outdir"), type = "character", default = ".", help = "结果文件目录 [default = %default]"),
	make_option(c("-p", "--prefix"), type = "character", default = NULL, help = "前缀 [default = %default]"),
	make_option(c("-m", "--method"), type = "character", default = "ssgsea", help = "前缀 [default = %default]")
);

opt_parser = OptionParser(option_list = option_list)
opt = parse_args(opt_parser)
inputFile <- opt$infile
gmtFile <- opt$gmt
outdir <- opt$outdir
prefix <- opt$prefix
method <- opt$method

# Load the required libraries
library(ggplot2)
library(scales)
library(dplyr)

# Set the working directory
setwd(outdir)

# Read the data from a CSV file
df <- read.csv(inputFile, sep = "\t")

# Normalize the "transporters," "GLS," "UCP," "Tau_formation," "Intracellular_pH_elevation," "Endosomal_pH," and "Lysosomal_pH" columns to [0, 0.5]
# and "FR" column to [0.5, 1]
normalized_df <- df %>%
  mutate(
    Amyloid_beta_formation__Extracellular_acidity_contributions = rescale(Amyloid_beta_formation__Extracellular_acidity_contributions, to = c(0, 1)),
    Amyloid_beta_formation__Neuron_death_contributions = rescale(Amyloid_beta_formation__Neuron_death_contributions, to = c(0, 1)),
    Neuron_death = rescale(Neuron_death, to = c(1, 1.5))
  )

# Create a color palette for the seven curves
curve_colors <- c("#0072B2", "#D55E00", "#009E73", "#CC79A7", "#E69F00", "#56B4E9", "#E76BF3")

plot <- ggplot(normalized_df, aes(x = Time)) +
  geom_smooth(aes(y = Neuron_death, color = "Neuron_death"), method = "loess", linewidth = 1.2, span = 1.3, se = FALSE, alpha = 0.5) +
  geom_smooth(aes(y = Amyloid_beta_formation__Extracellular_acidity_contributions, color = "Extracellular acidity cor amyloid"), method = "loess", linewidth = 1.2, span = 1.3, se = FALSE, alpha = 0.5) +
  geom_smooth(aes(y = Amyloid_beta_formation__Neuron_death_contributions, color = "Amyloid_cor_neuron_death"), method = "loess", linewidth = 1.2, span = 1.3, se = FALSE, alpha = 0.5, linetype = "dashed") +
  scale_color_manual(values = c("Neuron_death" = "red", "Extracellular acidity cor amyloid" = curve_colors[1], "Amyloid_cor_neuron_death" = curve_colors[2])) +
  scale_y_continuous(name = "Level of Fenton reaction", sec.axis = sec_axis(~./1, name = "Acidifying responses")) +
  theme(
    axis.title.y.left = element_text(color = "black", size = 16),
    axis.text.y.left = element_text(color = "black"),
    axis.title.y.right = element_text(color = "black", size = 16),
    axis.text.y.right = element_text(color = "black"),
    axis.text.x = element_text(color = "black",size = 14),
    axis.text.y = element_text(color = "black",size = 14),
    axis.title.x = element_text(color = "black", size = 16),
    legend.position = "right",
    legend.text = element_text(size = 13)
  )

# Save the plot as an image

ggsave(paste0(prefix, ".png"), plot, width = 12, height = 6, units = "in", dpi = 900)
ggsave(paste0(prefix, ".pdf"), plot, width = 12, height = 6, units = "in", dpi = 900)


