#!/python
#-*-coding:utf-8-*-
# 检查转录本(不提供表达量矩阵) 和 指定通路的回归关系 

def ss_edgeR():
	'''
	 
	'''
	import re,getopt,os,sys,optparse,glob,copy
	import pandas as pd
	from sklearn.decomposition import PCA	
	from statsmodels.formula.api import ols

	# [ read cmd by optparse modules ]
	usage="usage:python2 %prog [-options1 arg1] [-options2 arg2] ..."
	parser=optparse.OptionParser(usage,version="%prog 1.2")

	# input/output dir or file
	parser.add_option('--output', dest = 'output', type = 'string', help = 'the position of the result')
	parser.add_option('--prefix', dest = 'prefix', type = 'string', help = '')
	parser.add_option('--MCI_clinical', dest = 'MCI_clinical', type = 'string', help = '')
	parser.add_option('--AD_clinical', dest = 'AD_clinical', type = 'string', help = '')
	parser.add_option('--MCI_edgeR_indir', dest = 'MCI_edgeR_indir', type = 'string', help = '')
	parser.add_option('--AD_edgeR_indir', dest = 'AD_edgeR_indir', type = 'string', help = '')
	parser.add_option('--indir', dest = 'indir', type = 'string', help = '')
	parser.add_option('--tumor_name', dest = 'tumor_name', type = 'string', help = '')
	parser.add_option('--UP_DOWN', dest = 'UP_DOWN', type = 'string', help = '')
	parser.add_option('--PC', dest = 'PC', type = 'string', help = '')

	# oject the cmd
	(options,args) = parser.parse_args()

	# [public]
	output = options.output
	MCI_clinical = options.MCI_clinical
	AD_clinical = options.AD_clinical
	prefix = options.prefix
	MCI_edgeR_indir = options.MCI_edgeR_indir
	AD_edgeR_indir = options.AD_edgeR_indir
	indir = options.indir
	tumor_name = options.tumor_name
	UP_DOWN = options.UP_DOWN
	PC = options.PC

	if output:
		makedir_return = os.path.isdir(output) or os.makedirs(output)

	PC_df = pd.read_csv(PC, sep = "\t", index_col = "Gene")

	MCI_clinical_df = pd.read_csv(MCI_clinical, index_col = "specimenID", sep = "\t")
	MCI_clinical_df = MCI_clinical_df[MCI_clinical_df['sample_type'] == "MCI"]
	MCI_samples = MCI_clinical_df.index.tolist()
		
	AD_clinical_df = pd.read_csv(AD_clinical, index_col = "specimenID", sep = "\t")
	AD_clinical_df = AD_clinical_df[AD_clinical_df['sample_type'] == "AD"]
	AD_samples = AD_clinical_df.index.tolist()

	samples_dic = {}
	total_sample_df = pd.DataFrame()
	sample_ID = []
	total_FC = []
	group = []
	for par, dirs, files in os.walk(MCI_edgeR_indir):
		for subfile in files:
			if re.search(r"edgeR.result.xls", subfile):
				subfile_abspath = par + "/" + subfile
				sample_name = subfile.split(".")[0]
				df = pd.read_csv(subfile_abspath, sep = "\t", index_col = "Gene")
				inter_transcript = list(set(PC_df.index) & set(df.index))
				df = df.loc[inter_transcript]
				if UP_DOWN == "UP":
					DESeq_df = df[(df['PValue'] < 0.001) & (df['logFC'] > 0)]
				elif UP_DOWN == "DOWN":
					DESeq_df = df[(df['PValue'] < 0.05) & (df['logFC'] < 0)]
				else:
					DESeq_df = df[df['PValue'] < 0.05]
					
				total_fc = DESeq_df['logFC'].sum()
				samples_dic.setdefault(sample_name, total_FC)
#				samples_dic[sample_name].setdefault(, len(DESeq_df))
					
				sample_ID.append(sample_name)
				total_FC.append(total_fc)
#				total_FC.append(len(DESeq_df))
				group.append("MCI")

	for par, dirs, files in os.walk(AD_edgeR_indir):
		for subfile in files:
			if re.search(r"edgeR.result.xls", subfile):
				subfile_abspath = par + "/" + subfile
				sample_name = subfile.split(".")[0]
				df = pd.read_csv(subfile_abspath, sep = "\t", index_col = "Gene")
				inter_transcript = list(set(PC_df.index) & set(df.index))
				df = df.loc[inter_transcript]
				if UP_DOWN == "UP":
					DESeq_df = df[(df['PValue'] < 0.001) & (df['logFC'] > 0)]
				elif UP_DOWN == "DOWN":
					DESeq_df = df[(df['PValue'] < 0.05) & (df['logFC'] < 0)]
				else:
					DESeq_df = df[df['PValue'] < 0.05]
					
				total_fc = DESeq_df['logFC'].sum()
				samples_dic.setdefault(sample_name, total_FC)
#				samples_dic[sample_name].setdefault(, len(DESeq_df))

				sample_ID.append(sample_name)
				total_FC.append(total_fc)
#				total_FC.append(len(DESeq_df))
				group.append("AD")
			

	total_sample_df["Sample"] = sample_ID
	total_sample_df['total_FC'] = total_FC
	total_sample_df['group'] = group
	
	# 1. 按照 total_FC 列的值从小到大排序
	total_sample_df_sorted = total_sample_df.sort_values(by='total_FC')
	print(total_sample_df_sorted)

	# 2. 选择前 M 行样本
	top_M_samples = total_sample_df_sorted.head(len(MCI_samples))

	# 3. 计算 "MCI" 行数
	MCI_count = top_M_samples[top_M_samples['group'] == 'MCI'].shape[0]

	# 4. 计算 "MCI" 行数占 M 的比例
	MCI_percentage = MCI_count / len(MCI_samples) * 100
	print(MCI_percentage)


if __name__ == '__main__':
	'''
	'''	
	
	ss_edgeR()




	
