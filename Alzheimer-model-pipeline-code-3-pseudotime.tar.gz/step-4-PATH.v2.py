import pandas as pd
import pingouin as pg

# Sample data for A, B, C, D, and Z
data = {
    'A': [1, 2, 3, 4, 5],
    'B': [2, 3, 4, 5, 6],
    'C': [3, 4, 5, 6, 7],
    'D': [4, 5, 6, 7, 8],
    'Z': [5, 6, 7, 8, 9]
}

df = pd.DataFrame(data)

# Path Model: A -> Z
model_A_Z = 'Z ~ A'
results_A_Z = pg.path(data=df, model=model_A_Z)

# Path Model: A -> B -> Z
model_A_B_Z = 'Z ~ A + B'
results_A_B_Z = pg.path(data=df, model=model_A_B_Z)

# Path Model: C -> Z
model_C_Z = 'Z ~ C'
results_C_Z = pg.path(data=df, model=model_C_Z)

# Path Model: C -> D -> Z
model_C_D_Z = 'Z ~ C + D'
results_C_D_Z = pg.path(data=df, model=model_C_D_Z)

# Print the path coefficients and p-values for each model
print("A -> Z:")
print(results_A_Z['coef'])

print("\nA -> B -> Z:")
print(results_A_B_Z['coef'])

print("\nC -> Z:")
print(results_C_Z['coef'])

print("\nC -> D -> Z:")
print(results_C_D_Z['coef'])

