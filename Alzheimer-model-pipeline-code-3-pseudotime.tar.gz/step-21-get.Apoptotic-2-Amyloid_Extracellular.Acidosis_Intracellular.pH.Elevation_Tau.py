#!/python
#-*-coding:utf-8-*-
# 统计

def Wilcox():
	'''
	 
	'''
	import re,getopt,os,sys,optparse,glob,itertools,math
	import pandas as pd
	import scipy
	import scipy.stats as stats
	import numpy as np
	import statsmodels.api as sm

	# [ read cmd by optparse modules ]
	usage="usage:python2 %prog [-options1 arg1] [-options2 arg2] ..."
	parser=optparse.OptionParser(usage,version="%prog 1.2")

	# input/output dir or file
	parser.add_option('--extracellular_acidosis_ssGSEA', dest = 'extracellular_acidosis_ssGSEA', type = 'string', help = '')
	parser.add_option('--ssGSEA', dest = 'ssGSEA', type = 'string', help = '')
	parser.add_option('--check_cmb', dest = 'check_cmb', type = 'string', help = '')
	parser.add_option('--MCI_clinical_info', dest = 'MCI_clinical_info', type = 'string', help = '')
	parser.add_option('--AD_clinical_info', dest = 'AD_clinical_info', type = 'string', help = '')
	parser.add_option('--clinical_info', dest = 'clinical_info', type = 'string', help = '')
	parser.add_option('--output', dest = 'output', type = 'string', help = 'the position of the result')
	parser.add_option('--prefix', dest = 'prefix', type = 'string', help = '')
	parser.add_option('--extracellular_acidosis_label', dest = 'extracellular_acidosis_label', type = 'string', help = '')
	parser.add_option('--apoto_label', dest = 'apoto_label', type = 'string', help = '')

	# oject the cmd
	(options,args) = parser.parse_args()

	# [public]
	extracellular_acidosis_ssGSEA = options.extracellular_acidosis_ssGSEA
	ssGSEA = options.ssGSEA
	check_cmb = options.check_cmb
	MCI_clinical_info = options.MCI_clinical_info
	AD_clinical_info = options.AD_clinical_info
	clinical_info = options.clinical_info
	output = options.output
	prefix = options.prefix
	extracellular_acidosis_label = options.extracellular_acidosis_label
	apoto_label = options.apoto_label

	clinical_df = pd.read_csv(clinical_info, sep = "\t")
	Normal_samples = clinical_df[clinical_df['sample_type'] == "Normal"]['specimenID'].tolist()

	#	
	windows = ['0-40', '35-75','70-110','105-145','140-180','175-215','210-250','245-285','280-320','315-355']
	ssgsea_score = {}
	for par, subdirs, subfiles in os.walk(ssGSEA):
		for sub_ssgsea in subfiles:
			if re.search(r"-ssgsea-normalize.xls", sub_ssgsea) and re.search(r"step-steps.40-overlap5-MIX", par) and re.search(r"(Amyloid)|(Apoptotic)|(Extracellular.Acidosis)|(Intracellular.pH.Elevation)|(Tau)", par):
				sub_ssgsea_abspath = par + "/" + sub_ssgsea
				sub_ssgsea_df = pd.read_csv(sub_ssgsea_abspath, sep = "\t", index_col = "id")

				window_samples = []
				for ss in sub_ssgsea_df.columns:
					if ss not in Normal_samples:
						window_samples.append(ss)

				window_ssgsea_df = sub_ssgsea_df[window_samples]
#				print(window_ssgsea_mean)

				block = os.path.basename(par)
				ssgsea_score.setdefault(block, {})

				MCI_AD = sub_ssgsea.split("-")[0]
				window_name = MCI_AD + "-" + block
				
				for func in window_ssgsea_df.index:
					if re.search(r"Amyloid", par):
						ssgsea_score[block].setdefault('Amyloid', {})
						ssgsea_score[block]['Amyloid'].setdefault(func, window_ssgsea_df.loc[func, window_samples].tolist())
					if re.search(r"Apoptotic", par):
						ssgsea_score[block].setdefault('Apoptotic', {})
						ssgsea_score[block]['Apoptotic'].setdefault(func, window_ssgsea_df.loc[func, window_samples].tolist())
					if re.search(r"Extracellular", par):
						ssgsea_score[block].setdefault('Extracellular.Acidosis', {})
						ssgsea_score[block]['Extracellular.Acidosis'].setdefault(func, window_ssgsea_df.loc[func, window_samples].tolist())
					if re.search(r"Intracellular.pH", par):
						ssgsea_score[block].setdefault('Intracellular.pH.Elevation', {})
						ssgsea_score[block]['Intracellular.pH.Elevation'].setdefault(func, window_ssgsea_df.loc[func, window_samples].tolist())
					if re.search(r"Tau", par):
						ssgsea_score[block].setdefault('Tau', {})
						ssgsea_score[block]['Tau'].setdefault(func, window_ssgsea_df.loc[func, window_samples].tolist())

#	print(ssgsea_score)

	total_dic = {}	
	for wind in windows:
#		print("\n")
		total_wind_df = pd.DataFrame()
		for Apoptotic in ssgsea_score.get(wind).get('Apoptotic'):
#			print(Apoptotic)
#			if re.search(r"(neuron_apoptotic_process)|(execution_phase_of_apoptosis)", Apoptotic):
			if Apoptotic == "neuron_apoptotic_process" or Apoptotic == "execution_phase_of_apoptosis":
#				print(Apoptotic)
				for Amyloid in ssgsea_score.get(wind).get('Amyloid'):
#					print(Amyloid)	
					if re.search(r"amyloid-beta.formation", Amyloid):
#						print(Amyloid)
						for Acidosis in ssgsea_score.get(wind).get('Extracellular.Acidosis'):
#							print(Acidosis)
							if Acidosis == "ASIC" or Acidosis == "ASIC.2.3" or Acidosis == "ASIC2" or Acidosis == "ASIC3":
								for Elevation in ssgsea_score.get(wind).get('Intracellular.pH.Elevation'):
									for tau in ssgsea_score.get(wind).get('Tau'):
										total_wind_df["Apoptotic"] = ssgsea_score.get(wind).get('Apoptotic').get(Apoptotic)
										total_wind_df["Amyloid"] = ssgsea_score.get(wind).get('Amyloid').get(Amyloid)
										total_wind_df["Extracellular_acidosis"] = ssgsea_score.get(wind).get('Extracellular.Acidosis').get(Acidosis)
										total_wind_df["Intracellular_alkalosis"] = ssgsea_score.get(wind).get('Intracellular.pH.Elevation').get(Elevation)
										total_wind_df["Tau"] = ssgsea_score.get(wind).get('Tau').get(tau)
		#								print(total_wind_df)								
		
										makedir_return = os.path.isdir(output + "/" + wind) or os.makedirs(output + "/" + wind)
										outfile = output + "/" + wind + "/" + Apoptotic + "-" + Amyloid + "-" + Acidosis + "-" + Elevation + "-" + tau + ".xls"
										total_wind_df.to_csv(outfile, sep = "\t", index = False)

										# Mediation Analysis: Extracellular.acidosis -> Amyloid -> Apoptotic
										model_Amyloid_Extracellular_acidosis = sm.OLS.from_formula('Amyloid ~ Extracellular_acidosis', data = total_wind_df).fit()
										model_Apoptotic_Extracellular_acidosis = sm.OLS.from_formula('Apoptotic ~ Extracellular_acidosis', data = total_wind_df).fit()
										model_Apoptotic_Amyloid = sm.OLS.from_formula('Apoptotic ~ Amyloid', data = total_wind_df).fit()

										# Get the indirect effect of A on Z through B (mediation effect)
										Apoptotic_Amyloid_pvalue = model_Apoptotic_Amyloid.pvalues['Amyloid']
#										Apoptotic_Extracellular_acidosis_indirect_effect = model_Amyloid_Extracellular_acidosis.params['Extracellular_acidosis'] * model_Apoptotic_Amyloid.params['Amyloid'] *math.log10(Apoptotic_Amyloid_pvalue)
										Apoptotic_Extracellular_acidosis_indirect_effect = abs(model_Amyloid_Extracellular_acidosis.params['Extracellular_acidosis']) * model_Apoptotic_Amyloid.params['Amyloid']		# 不考虑 pvalue 影响
										Extracellular_acidosis_pvalues = model_Amyloid_Extracellular_acidosis.pvalues['Extracellular_acidosis']
#										print(Extracellular_acidosis_pvalues)

										# Print the results
										Apoptotic_Extracellular_acidosis_pvalue = model_Apoptotic_Extracellular_acidosis.pvalues['Extracellular_acidosis']
#										Apoptotic_Extracellular_acidosis_total_effect = model_Apoptotic_Extracellular_acidosis.params['Extracellular_acidosis']*math.log10(Apoptotic_Extracellular_acidosis_pvalue) + Apoptotic_Extracellular_acidosis_indirect_effect
										Apoptotic_Extracellular_acidosis_total_effect = model_Apoptotic_Extracellular_acidosis.params['Extracellular_acidosis'] + Apoptotic_Extracellular_acidosis_indirect_effect

										Apoptotic_Amyloid_total_effect = model_Apoptotic_Amyloid.params['Amyloid']

										# Mediation Analysis: Intracellular_alkalosis -> Tau -> Apoptotic
										model_Tau_Intracellular_alkalosis = sm.OLS.from_formula('Tau ~ Intracellular_alkalosis', data = total_wind_df).fit()
										model_Apoptotic_Intracellular_alkalosis = sm.OLS.from_formula('Apoptotic ~ Intracellular_alkalosis', data = total_wind_df).fit()
										model_Apoptotic_Tau = sm.OLS.from_formula('Apoptotic ~ Tau', data = total_wind_df).fit()
										Apoptotic_Tau_pavlue = model_Apoptotic_Tau.pvalues['Tau']
										Tau_Intracellular_alkalosis_pavlue = model_Tau_Intracellular_alkalosis.pvalues['Intracellular_alkalosis']
										Apoptotic_Intracellular_alkalosis_pavlue = model_Apoptotic_Intracellular_alkalosis.pvalues['Intracellular_alkalosis']

										# Get the indirect effect of A on Z through B (mediation effect)
#										Apoptotic_Intracellular_alkalosis_indirect_effect = model_Tau_Intracellular_alkalosis.params['Intracellular_alkalosis'] * model_Apoptotic_Tau.params['Tau'] * math.log10(Apoptotic_Tau_pavlue)
										Apoptotic_Intracellular_alkalosis_indirect_effect = abs(model_Tau_Intracellular_alkalosis.params['Intracellular_alkalosis']) *model_Apoptotic_Tau.params['Tau']

										# Print the results
#										Apoptotic_Intracellular_alkalosis_total_effect = model_Apoptotic_Intracellular_alkalosis.params['Intracellular_alkalosis'] * math.log10(Apoptotic_Intracellular_alkalosis_pavlue) + Apoptotic_Intracellular_alkalosis_indirect_effect 
										Apoptotic_Intracellular_alkalosis_total_effect = model_Apoptotic_Intracellular_alkalosis.params['Intracellular_alkalosis'] + Apoptotic_Intracellular_alkalosis_indirect_effect
																				
										Apoptotic_Tau_total_effect = model_Apoptotic_Tau.params['Tau']

#										total_wind_df = pd.DataFrame()
#										print(Apoptotic_Extracellular_acidosis_total_effect, Apoptotic_Amyloid_total_effect, Apoptotic_Intracellular_alkalosis_total_effect, Apoptotic_Tau_total_effect)

										# 4 组竞争模型
										model_Apoptotic_Extracellular_acidosis_Amyloid_Intracellular_alkalosis_Tau = sm.OLS.from_formula('Apoptotic ~ Extracellular_acidosis + Amyloid + Intracellular_alkalosis + Tau', data = total_wind_df).fit()
										group_4_Amyloid_coeff = model_Apoptotic_Extracellular_acidosis_Amyloid_Intracellular_alkalosis_Tau.params['Amyloid']
#										print(group_4_Amyloid_coeff)
										group_4_Tau_coeff = model_Apoptotic_Extracellular_acidosis_Amyloid_Intracellular_alkalosis_Tau.params['Tau']
#										print(group_4_Tau_coeff)
										group_4_Extracellular_acidosis_coeff = model_Apoptotic_Extracellular_acidosis_Amyloid_Intracellular_alkalosis_Tau.params['Extracellular_acidosis'] + model_Amyloid_Extracellular_acidosis.params['Extracellular_acidosis'] * group_4_Amyloid_coeff
#										group_4_Extracellular_acidosis_coeff = model_Apoptotic_Extracellular_acidosis_Amyloid_Intracellular_alkalosis_Tau.params['Extracellular_acidosis']

#										print(group_4_Extracellular_acidosis_coeff)
										group_4_Intracellular_alkalosis_coeff = model_Apoptotic_Extracellular_acidosis_Amyloid_Intracellular_alkalosis_Tau.params['Intracellular_alkalosis'] + model_Tau_Intracellular_alkalosis.params['Intracellular_alkalosis'] * group_4_Tau_coeff
#										group_4_Intracellular_alkalosis_coeff = model_Apoptotic_Extracellular_acidosis_Amyloid_Intracellular_alkalosis_Tau.params['Intracellular_alkalosis']

										cmb = Apoptotic + "-" + Amyloid + "-" + Acidosis + "-" + Elevation + "-" + tau
										total_dic.setdefault(cmb, {})
										total_dic[cmb].setdefault(wind, {})
										total_dic[cmb][wind].setdefault("Amyloid", Apoptotic_Amyloid_total_effect)
										total_dic[cmb][wind].setdefault("Extracellular_acidosis", Apoptotic_Extracellular_acidosis_total_effect)
										total_dic[cmb][wind].setdefault("Tau", Apoptotic_Tau_total_effect)
										total_dic[cmb][wind].setdefault("Intracellular_alkalosis", Apoptotic_Intracellular_alkalosis_total_effect)

										total_dic[cmb][wind].setdefault("Amyloid-4group", group_4_Amyloid_coeff)
										total_dic[cmb][wind].setdefault("Extracellular_acidosis-4group", group_4_Extracellular_acidosis_coeff)
										total_dic[cmb][wind].setdefault("Tau-4group", group_4_Tau_coeff)
										total_dic[cmb][wind].setdefault("Intracellular_alkalosis-4group", group_4_Intracellular_alkalosis_coeff)

#	for sub_cmb in total_dic:
#		print(sub_cmb, "\n")
#		for sub_wind in windows:
#			print(sub_wind, " acidosis = ", round(total_dic.get(sub_cmb).get(sub_wind).get("Extracellular_acidosis"), 3), " || Amyloid = ", round(total_dic.get(sub_cmb).get(sub_wind).get("Amyloid"), 3), " || alkalosis = ", round(total_dic.get(sub_cmb).get(sub_wind).get("Intracellular_alkalosis"), 3), " || Tau = ", round(total_dic.get(sub_cmb).get(sub_wind).get("Tau"), 3))

	amyloid_coeff = []
	Extracellular_acidosis_coeff = []
	alkalosis_coeff = []
	Tau_coeff = []
	print("最佳模型 : ")
	for sub_cmb in total_dic:
#		if sub_cmb == "execution_phase_of_apoptosis-amyloid-beta.formation-ASIC2-intracellular.pH.elevation-tau_protein_binding":	# 最佳组合
		if sub_cmb == check_cmb:
#		if not re.search(r"intracellular.pH.reduction", sub_cmb):
			print(sub_cmb)
			for sub_wind in windows:
				print(sub_wind, " acidosis = ", round(total_dic.get(sub_cmb).get(sub_wind).get("Extracellular_acidosis"), 3), " || Amyloid = ", round(total_dic.get(sub_cmb).get(sub_wind).get("Amyloid"), 3), " || alkalosis = ", round(total_dic.get(sub_cmb).get(sub_wind).get("Intracellular_alkalosis"), 3), " || Tau = ", round(total_dic.get(sub_cmb).get(sub_wind).get("Tau"), 3))

				amyloid_coeff.append(str(round(total_dic.get(sub_cmb).get(sub_wind).get("Amyloid"), 3)))
				Extracellular_acidosis_coeff.append(str(round(total_dic.get(sub_cmb).get(sub_wind).get("Extracellular_acidosis"), 3)))
				alkalosis_coeff.append(str(round(total_dic.get(sub_cmb).get(sub_wind).get("Intracellular_alkalosis"), 3)))
				Tau_coeff.append(str(round(total_dic.get(sub_cmb).get(sub_wind).get("Tau"), 3)))
	print("amyloid_coeff : \n", "\n".join(amyloid_coeff))
	print("Extracellular_acidosis_coeff : \n", "\n".join(Extracellular_acidosis_coeff))
	print("alkalosis_coeff : \n", "\n".join(alkalosis_coeff))
	print("Tau_coeff : \n", "\n".join(Tau_coeff))

	print("最佳模型 : ")
	for sub_cmb in total_dic:
#		if sub_cmb == "execution_phase_of_apoptosis-amyloid-beta.formation-ASIC2-intracellular.pH.elevation-tau_protein_binding":	# 最佳组合
		if sub_cmb == check_cmb:
			for sub_wind in windows:
				print(sub_wind, " 4group acidosis = ", round(total_dic.get(sub_cmb).get(sub_wind).get("Extracellular_acidosis-4group"), 3), " || Amyloid = ", round(total_dic.get(sub_cmb).get(sub_wind).get("Amyloid-4group"), 3), " || alkalosis = ", round(total_dic.get(sub_cmb).get(sub_wind).get("Intracellular_alkalosis-4group"), 3), " || Tau = ", round(total_dic.get(sub_cmb).get(sub_wind).get("Tau-4group"), 3))




if __name__ == '__main__':
	'''
	'''	
	
	Wilcox()

