#!/python
#-*-coding:utf-8-*-
# 统计

def Pseudotime():
	'''
	 
	'''
	import re,getopt,os,sys,optparse,glob,itertools
	import pandas as pd
	import scipy
	import scipy.stats as stats
	import statsmodels.api as sm
	import numpy as np

	# [ read cmd by optparse modules ]
	usage="usage:python2 %prog [-options1 arg1] [-options2 arg2] ..."
	parser=optparse.OptionParser(usage,version="%prog 1.2")

	# input/output dir or file
	parser.add_option('--extracellular_acidosis_MCI_Extracellular_acidity_2Events', dest = 'extracellular_acidosis_MCI_Extracellular_acidity_2Events', type = 'string', help = '')
	parser.add_option('--MCI_Extracellular_acidity_2Events', dest = 'MCI_Extracellular_acidity_2Events', type = 'string', help = '')
	parser.add_option('--AD_Extracellular_acidity_2Events', dest = 'AD_Extracellular_acidity_2Events', type = 'string', help = '')
	parser.add_option('--MCI_clinical_info', dest = 'MCI_clinical_info', type = 'string', help = '')
	parser.add_option('--AD_clinical_info', dest = 'AD_clinical_info', type = 'string', help = '')
	parser.add_option('--clinical_info', dest = 'clinical_info', type = 'string', help = '')
	parser.add_option('--output', dest = 'output', type = 'string', help = 'the position of the result')
	parser.add_option('--prefix', dest = 'prefix', type = 'string', help = '')
	parser.add_option('--Pseudotime', dest = 'Pseudotime', type = 'string', help = '')
	parser.add_option('--Pseudotime_indir', dest = 'Pseudotime_indir', type = 'string', help = '')

	# oject the cmd
	(options,args) = parser.parse_args()

	# [public]
	extracellular_acidosis_MCI_Extracellular_acidity_2Events = options.extracellular_acidosis_MCI_Extracellular_acidity_2Events
	MCI_Extracellular_acidity_2Events = options.MCI_Extracellular_acidity_2Events
	AD_Extracellular_acidity_2Events = options.AD_Extracellular_acidity_2Events
	MCI_clinical_info = options.MCI_clinical_info
	AD_clinical_info = options.AD_clinical_info
	clinical_info = options.clinical_info
	output = options.output
	prefix = options.prefix
	Pseudotime = options.Pseudotime
	Pseudotime_indir = options.Pseudotime_indir

	# 读取包含9列信息的文件
	MCI_score_data = pd.read_csv(MCI_Extracellular_acidity_2Events, index_col = "Sample", sep = "\t")
	AD_score_data = pd.read_csv(AD_Extracellular_acidity_2Events, index_col = "Sample", sep = "\t")
	AD_score_data = AD_score_data[MCI_score_data.columns]
	score_data = MCI_score_data.append(AD_score_data)

	# 设定bin的大小和步长
	bin_size = 40
	step_size = 10
	
	# 初始化一个DataFrame来存储结果
	results = pd.DataFrame(columns=['bin', "Neuron_death", "Extracellular_acidity", "Amyloid_beta_formation", "Intracellular_pH_elevation", "Tau_formation"])
	
	# 创建函数来计算多元回归模型的BIC值
	def calculate_BIC(X, y):
#		model = sm.OLS(y, sm.add_constant(X)).fit()
		model = sm.OLS(y, X).fit()
		BIC = model.bic
		return BIC

	def calculate_coeff(X, y):
		model = sm.OLS(y, X).fit()
		coef_A = model.params[X.columns.tolist()[0]]  # Get the coefficient for Extracellular_acidity
		return coef_A
	
	# 遍历时间序列文件目录
	output_directory = output
	if not os.path.exists(output_directory):
		os.makedirs(output_directory)
	
	# 初始化之前的斜率和斜率列表
	prev_Amyloid_beta_formation_slope = None
	prev_Extracellular_acidity_slope = None
	Amyloid_beta_formation_slopes = []
	Extracellular_acidity_slopes = []
	Intracellular_pH_elevation_slopes = []
	Tau_formation_slopes = []

	time_series_directory = Pseudotime_indir	
	# 遍历时间序列文件目录
	for time_series_file in os.listdir(time_series_directory):
		time_series_data = pd.read_csv(os.path.join(time_series_directory, time_series_file), sep="\t")
		score_data2 = score_data.loc[time_series_data['Sample']]

		Amyloid_beta_formation_contributions = []
		Extracellular_acidity_contributions = []
		Intracellular_pH_elevation_contributions = []
		Tau_formation_contributions = []
		Neuron_death = []

		for bin_start in range(0, len(time_series_data), step_size):
			bin_end = bin_start + bin_size
	
			if bin_end > len(time_series_data):
				break
	
			bin_group = time_series_data.iloc[bin_start:bin_end]
			X = score_data2.loc[bin_group['Sample'], ["Extracellular_acidity", "Amyloid_beta_formation", "Intracellular_pH_elevation", "Tau_formation"]]
			y = score_data2.loc[bin_group['Sample'], ["Neuron_death"]]
			Neuron_death.append(float(y.mean()))

			Extracellular_acidity_2_Amyloid_coeff = calculate_coeff(score_data2.loc[bin_group['Sample'], ["Extracellular_acidity"]], score_data2.loc[bin_group['Sample'], ["Amyloid_beta_formation"]])
			Intracellular_pH_elevation_2_Tau_formation_coeff = calculate_coeff(score_data2.loc[bin_group['Sample'], ["Intracellular_pH_elevation"]], score_data2.loc[bin_group['Sample'], ["Tau_formation"]])	

			A_BIC = calculate_BIC(X, y)
			variable_contributions = []
	
			for variable in ["Amyloid_beta_formation", "Tau_formation", "Extracellular_acidity", "Intracellular_pH_elevation"]:	# 特定顺序
				X_temp = X.drop(variable, axis=1)
				B_BIC = calculate_BIC(X_temp, y)
				contribution = B_BIC - A_BIC
				variable_contributions.append((variable, contribution))
				if variable == "Amyloid_beta_formation":
					Amyloid_beta_formation_contributions.append(contribution)

				if variable == "Extracellular_acidity":
					contribution_total = contribution + Amyloid_beta_formation_contributions[-1] * Extracellular_acidity_2_Amyloid_coeff	
					Extracellular_acidity_contributions.append(contribution_total)

				if variable == "Intracellular_pH_elevation":
					contribution_total = contribution + Tau_formation_contributions[-1] * Intracellular_pH_elevation_2_Tau_formation_coeff
					Intracellular_pH_elevation_contributions.append(contribution_total)
		
				if variable == "Tau_formation":
					Tau_formation_contributions.append(contribution)

		# 如果有足够的数据点，计算Amyloid_beta_formation和Extracellular_acidity的斜率
		if len(Amyloid_beta_formation_contributions) > 1:
			Amyloid_beta_formation_slope = np.polyfit(range(len(Amyloid_beta_formation_contributions)), Amyloid_beta_formation_contributions, 1)[0]
#			print(Amyloid_beta_formation_slope)
#			Amyloid_beta_formation_slopes.append(Amyloid_beta_formation_slope)
		if len(Extracellular_acidity_contributions) > 1:
			Extracellular_acidity_slope = np.polyfit(range(len(Extracellular_acidity_contributions)), Extracellular_acidity_contributions, 1)[0]
#			print(Extracellular_acidity_slope)
#			Extracellular_acidity_slopes.append(Extracellular_acidity_slope)
		if len(Intracellular_pH_elevation_contributions) > 1:
			Intracellular_pH_elevation_slopes = np.polyfit(range(len(Intracellular_pH_elevation_contributions)), Intracellular_pH_elevation_contributions, 1)[0]

		if len(Tau_formation_contributions) > 1:
			Tau_formation_slopes = np.polyfit(range(len(Tau_formation_contributions)), Tau_formation_contributions, 1)[0]

		print(Amyloid_beta_formation_slope, Extracellular_acidity_slope, Intracellular_pH_elevation_slopes, Tau_formation_slopes)
		# 检查斜率条件
		if Amyloid_beta_formation_slope != 0 and Extracellular_acidity_slope != 0:
#			print(time_series_file.split(".xls")[0] + "-Neuron_death-4Events.xls", "Amyloid_beta_formation_slope : ", Amyloid_beta_formation_slope, " Extracellular_acidity_slope : ", Extracellular_acidity_slope, " Intracellular_pH_elevation_slopes : ", Intracellular_pH_elevation_slopes, " Tau_formation_slopes : ", Tau_formation_slopes)
			results_df = pd.DataFrame()
			results_df['Amyloid_beta_formation'] = Amyloid_beta_formation_contributions
			results_df['Extracellular_acidity'] = Extracellular_acidity_contributions
			results_df['Intracellular_pH_elevation'] = Intracellular_pH_elevation_contributions
			results_df['Tau_formation'] = Tau_formation_contributions
			results_df['Neuron_death'] = Neuron_death

			# 保存满足条件的结果
			results_df.to_csv(os.path.join(output_directory, time_series_file.split(".xls")[0] + "-Neuron_death-4Events.xls"), index_label = "Time", sep = "\t")
	

if __name__ == '__main__':
	'''
	'''	
	
	Pseudotime()

