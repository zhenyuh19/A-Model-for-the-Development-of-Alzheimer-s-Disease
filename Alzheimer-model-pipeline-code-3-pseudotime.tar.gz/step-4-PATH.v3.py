import pandas as pd
import statsmodels.api as sm

# Sample data for A, B, and Z
data = {
    'A': [1, 2, 23, 14, 5],
    'B': [2, 6, 4, 10, 6],
    'Z': [5, 6, 7, 8, 9]
}

df = pd.DataFrame(data)

# Mediation Analysis: A -> B -> Z
model_A_B = sm.OLS.from_formula('B ~ A', data=df).fit()
model_Z_B = sm.OLS.from_formula('Z ~ B', data=df).fit()

# Get the indirect effect of A on Z through B (mediation effect)
indirect_effect = model_A_B.params['A'] * model_Z_B.params['B']

# Print the results
print(model_A_B.summary2())
print(model_Z_B.summary2())
print("Direct effect of A on Z:", model_Z_B.params['B'])
print("Indirect effect of A on Z through B (Mediation effect):", indirect_effect)
print("Total effect of A on Z:", model_A_B.params['A'] + indirect_effect)

