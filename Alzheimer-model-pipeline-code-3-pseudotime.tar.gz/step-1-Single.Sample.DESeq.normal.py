#!/python
#-*-coding:utf-8-*-
# 检查转录本(不提供表达量矩阵) 和 指定通路的回归关系 

def ss_edgeR():
	'''
	 
	'''
	import re,getopt,os,sys,optparse,glob,copy
	import pandas as pd
	from sklearn.decomposition import PCA	
	from statsmodels.formula.api import ols

	# [ read cmd by optparse modules ]
	usage="usage:python2 %prog [-options1 arg1] [-options2 arg2] ..."
	parser=optparse.OptionParser(usage,version="%prog 1.2")

	# input/output dir or file
	parser.add_option('--output', dest = 'output', type = 'string', help = 'the position of the result')
	parser.add_option('--prefix', dest = 'prefix', type = 'string', help = '')
	parser.add_option('--tpm', dest = 'tpm', type = 'string', help = '')
	parser.add_option('--clinical', dest = 'clinical', type = 'string', help = '')
	parser.add_option('--count', dest = 'count', type = 'string', help = '')
	parser.add_option('--block', dest = 'block', type = 'string', help = '')
	parser.add_option('--indir', dest = 'indir', type = 'string', help = '')
	parser.add_option('--tumor_name', dest = 'tumor_name', type = 'string', help = '')

	# oject the cmd
	(options,args) = parser.parse_args()

	# [public]
	output = options.output
	tpm = options.tpm
	clinical = options.clinical
	prefix = options.prefix
	count = options.count
	block = options.block
	indir = options.indir
	tumor_name = options.tumor_name

	if output:
		makedir_return = os.path.isdir(output) or os.makedirs(output)
	
	if tpm:
		tpm_df = pd.read_csv(tpm, sep = "\t", index_col = "Gene")
	if count:
		count_df = pd.read_csv(count, sep = "\t", index_col = "transcript_id")

	def edgeR(count, ctr_numb, disease_numb, gene_length_file, outdir, prefix):
		shell = '''Rscript  /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-6-pseudotime/ss.edgeR.R \\
	--count {_count} \\
	--ctr_numb {_ctr_numb} \\
	--disease_numb {_disease_numb} \\
	--gene.length {_gene_length} \\
	--outdir {_outdir} \\
	--prefix {_prefix}

'''.format(_count = count, _ctr_numb = ctr_numb, _disease_numb = disease_numb, _gene_length = gene_length_file, _outdir = outdir, _prefix = prefix)

		return shell

	clinical_df = pd.read_csv(clinical, sep = "\t", index_col = "specimenID")
	normal_samples = clinical_df[clinical_df['sample_type'] == "Normal"].index.tolist()
	case_samples = clinical_df[clinical_df['sample_type'] == "AD"].index.tolist()
	block_df = pd.read_csv(block, index_col = "transcript", sep = "\t")	
	block_df = block_df.loc[count_df.index.tolist()]
	block_df = block_df['Gene.Length']
	gene_length_outfile = output + "/StringTie.gene.length.xls"
	block_df.to_csv(gene_length_outfile, sep = "\t", index_label = "Gene")
	edgeR_outdir = output + "/edgeR"
	makedir_return = os.path.isdir(edgeR_outdir) or os.makedirs(edgeR_outdir)
	i = 0
	for ss in normal_samples:
		if not os.path.isfile(edgeR_outdir + "/" + ss + ".edgeR.result.xls"):
			Normal_ssCase = case_samples + [ss]
			Normal_ssCase_count_df = count_df[Normal_ssCase]
			Normal_ssCase_outfile = edgeR_outdir + "/" + ss + ".count.xls"
			Normal_ssCase_count_df.to_csv(Normal_ssCase_outfile, sep = "\t", index_label = "Gene")
			edgeR_shell = edgeR(count = Normal_ssCase_outfile, ctr_numb = len(case_samples), disease_numb = 1, gene_length_file = gene_length_outfile, outdir = edgeR_outdir, prefix = ss)
			edgeR_outshell = edgeR_outdir + "/" + ss + ".edgeR.sh"
			with open(edgeR_outshell, "w") as OUT:
				OUT.write(edgeR_shell)

			if i < 40:
				i += 1
				os.system("nohup sh {_edgeR_outshell} > {_edgeR_outshell}.o 2 > {_edgeR_outshell}.e &".format(_edgeR_outshell = edgeR_outshell))
		else:
			print(ss)
				


if __name__ == '__main__':
	'''
	'''	
	
	ss_edgeR()




	
