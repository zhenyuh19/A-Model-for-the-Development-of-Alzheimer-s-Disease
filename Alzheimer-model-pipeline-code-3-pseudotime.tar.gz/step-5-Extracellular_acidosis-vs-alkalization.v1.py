#!/python
#-*-coding:utf-8-*-
# 统计

def Pseudotime():
	'''
	 
	'''
	import re,getopt,os,sys,optparse,glob,itertools
	import pandas as pd
	import scipy
	import scipy.stats as stats
	import statsmodels.api as sm
	import numpy as np

	# [ read cmd by optparse modules ]
	usage="usage:python2 %prog [-options1 arg1] [-options2 arg2] ..."
	parser=optparse.OptionParser(usage,version="%prog 1.2")

	# input/output dir or file
	parser.add_option('--extracellular_acidosis_MCI_Extracellular_acidity_2Events', dest = 'extracellular_acidosis_MCI_Extracellular_acidity_2Events', type = 'string', help = '')
	parser.add_option('--MCI_Extracellular_acidity_2Events', dest = 'MCI_Extracellular_acidity_2Events', type = 'string', help = '')
	parser.add_option('--AD_Extracellular_acidity_2Events', dest = 'AD_Extracellular_acidity_2Events', type = 'string', help = '')
	parser.add_option('--MCI_clinical_info', dest = 'MCI_clinical_info', type = 'string', help = '')
	parser.add_option('--AD_clinical_info', dest = 'AD_clinical_info', type = 'string', help = '')
	parser.add_option('--clinical_info', dest = 'clinical_info', type = 'string', help = '')
	parser.add_option('--output', dest = 'output', type = 'string', help = 'the position of the result')
	parser.add_option('--prefix', dest = 'prefix', type = 'string', help = '')
	parser.add_option('--Pseudotime', dest = 'Pseudotime', type = 'string', help = '')
	parser.add_option('--Pseudotime_indir', dest = 'Pseudotime_indir', type = 'string', help = '')

	# oject the cmd
	(options,args) = parser.parse_args()

	# [public]
	extracellular_acidosis_MCI_Extracellular_acidity_2Events = options.extracellular_acidosis_MCI_Extracellular_acidity_2Events
	MCI_Extracellular_acidity_2Events = options.MCI_Extracellular_acidity_2Events
	AD_Extracellular_acidity_2Events = options.AD_Extracellular_acidity_2Events
	MCI_clinical_info = options.MCI_clinical_info
	AD_clinical_info = options.AD_clinical_info
	clinical_info = options.clinical_info
	output = options.output
	prefix = options.prefix
	Pseudotime = options.Pseudotime
	Pseudotime_indir = options.Pseudotime_indir

	# 读取包含9列信息的文件
	MCI_score_data = pd.read_csv(MCI_Extracellular_acidity_2Events, index_col = "Sample", sep = "\t")
	AD_score_data = pd.read_csv(AD_Extracellular_acidity_2Events, index_col = "Sample", sep = "\t")
	AD_score_data = AD_score_data[MCI_score_data.columns]
	score_data = MCI_score_data.append(AD_score_data)

	# 设定bin的大小和步长
	bin_size = 40
	step_size = 10
	
	# 初始化一个DataFrame来存储结果
	results = pd.DataFrame(columns=['bin', "Extracellular_acidity", "Amyloid_beta_formation", "Neuron_death"])
	
	# 创建函数来计算多元回归模型的BIC值
	def calculate_BIC(X, y):
#		model = sm.OLS(y, sm.add_constant(X)).fit()
		model = sm.OLS(y, X).fit()
		BIC = model.bic
		return BIC
	
	# 遍历时间序列文件目录
	output_directory = output
	if not os.path.exists(output_directory):
		os.makedirs(output_directory)
	
	# 初始化之前的斜率和斜率列表
	prev_Amyloid_beta_formation_slope = None
	prev_Neuron_death_slope = None
	Amyloid_beta_formation_slopes = []
	Neuron_death_slopes = []

	time_series_directory = Pseudotime_indir
	diff_slope_dic = {}
	# 遍历时间序列文件目录
	for time_series_file in os.listdir(time_series_directory):
		time_series_data = pd.read_csv(os.path.join(time_series_directory, time_series_file), sep="\t")
		score_data2 = score_data.loc[time_series_data['Sample']]

		Amyloid_beta_formation__Extracellular_acidity_contributions = []
		Amyloid_beta_formation__Neuron_death_contributions = []
		Neuron_death = []

		for bin_start in range(0, len(time_series_data), step_size):
			bin_end = bin_start + bin_size
	
			if bin_end > len(time_series_data):
				break
	
			bin_group = time_series_data.iloc[bin_start:bin_end]
			X = score_data2.loc[bin_group['Sample'], ["Extracellular_acidity", "Neuron_death"]]
			y = score_data2.loc[bin_group['Sample'], ["Amyloid_beta_formation"]]
#			Neuron_death.append(float(y.mean()))
			Neuron_death.append(float(score_data2.loc[bin_group['Sample'], ["Neuron_death"]].mean()))
	
			A_BIC = calculate_BIC(X, y)
			variable_contributions = []
	
			for variable in X.columns:
				contribution, pvalue = stats.spearmanr(X[variable].tolist(), y)
				if variable == "Extracellular_acidity":
					Amyloid_beta_formation__Extracellular_acidity_contributions.append(contribution)

				if variable == "Neuron_death":
					Amyloid_beta_formation__Neuron_death_contributions.append(contribution)

		# 如果有足够的数据点，计算Amyloid_beta_formation和Neuron_death的斜率
#		print(Amyloid_beta_formation__Extracellular_acidity_contributions, Amyloid_beta_formation__Neuron_death_contributions)

		if len(Amyloid_beta_formation__Extracellular_acidity_contributions) > 1:
			Amyloid_beta_formation__Extracellular_acidity_slope = np.polyfit(range(len(Amyloid_beta_formation__Extracellular_acidity_contributions)), Amyloid_beta_formation__Extracellular_acidity_contributions, 1)[0]
#			print(Amyloid_beta_formation_slope)
		if len(Amyloid_beta_formation__Neuron_death_contributions) > 1:
			Amyloid_beta_formation__Neuron_death_slope = np.polyfit(range(len(Amyloid_beta_formation__Neuron_death_contributions)), Amyloid_beta_formation__Neuron_death_contributions, 1)[0]
#			print(Neuron_death_slope)

#		print(Amyloid_beta_formation_slope, Neuron_death_slope)
		diff_slope = Amyloid_beta_formation__Neuron_death_slope - Amyloid_beta_formation__Extracellular_acidity_slope
		# 检查斜率条件
		if Amyloid_beta_formation__Extracellular_acidity_slope > 0 and Amyloid_beta_formation__Neuron_death_slope > 0 and diff_slope > 0:
			print(time_series_file.split(".xls")[0] + "-Amyloid-2Events.xls", "Amyloid_beta_formation__Extracellular_acidity_slope : ", diff_slope)
			results_df = pd.DataFrame()
			results_df['Amyloid_beta_formation__Extracellular_acidity_contributions'] = Amyloid_beta_formation__Extracellular_acidity_contributions
			results_df['Amyloid_beta_formation__Neuron_death_contributions'] = Amyloid_beta_formation__Neuron_death_contributions
			results_df['Neuron_death'] = Neuron_death

			diff_slope_dic.setdefault(diff_slope, time_series_file.split(".xls")[0] + "-Amyloid-2Events.xls")

			# 保存满足条件的结果
			results_df.to_csv(os.path.join(output_directory, time_series_file.split(".xls")[0] + "-Amyloid-2Events.xls"), index_label = "Time", sep = "\t")
	
	sorted_keys = sorted(diff_slope_dic.keys())
	max_key = sorted_keys[-1]
	max_value = diff_slope_dic[max_key]
	print(max_value)

	
if __name__ == '__main__':
	'''
	'''	
	
	Pseudotime()

