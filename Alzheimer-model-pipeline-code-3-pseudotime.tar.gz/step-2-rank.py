#!/python

import pandas as pd
import os,sys,re,glob
import numpy as np

indir = sys.argv[1]
samples_dic = {}
UP_DOWN = sys.argv[3]
for par, dir_lst, file_lst in os.walk(indir):
	for subfile in file_lst:
		if re.search(r"edgeR.result.xls", subfile):
			subfile_abspath = par + "/" + subfile
			sample_name = subfile.split(".")[0]
			df = pd.read_csv(subfile_abspath, sep = "\t", index_col = "Gene")
			if UP_DOWN == "UP":
				DESeq_df = df[(df['PValue'] < 0.05) & (df['logFC'] > 0)]
			elif UP_DOWN == "DOWN":
				DESeq_df = df[(df['PValue'] < 0.05) & (df['logFC'] < 0)]
			else:
				DESeq_df = df[df['PValue'] < 0.05]

			samples_dic.setdefault("Sign.Count", {})
			samples_dic['Sign.Count'].setdefault(sample_name, len(DESeq_df))	

samples_df = pd.DataFrame.from_dict(samples_dic)
#print(samples_df)
samples_df = samples_df.sort_values(by = ['Sign.Count'])

outfile = sys.argv[2] + "-" + UP_DOWN + "-samples.rank.result.xls"
samples_df.to_csv(outfile, sep = "\t", index_label = "Sample")
