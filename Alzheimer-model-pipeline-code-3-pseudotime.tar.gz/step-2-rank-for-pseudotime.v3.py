#!/python
#-*-coding:utf-8-*-
# 检查转录本(不提供表达量矩阵) 和 指定通路的回归关系 

def ss_DESeq2():
	'''
	 
	'''
	import re,getopt,os,sys,optparse,glob,copy,itertools,math
	import pandas as pd
	import pickle

	# [ read cmd by optparse modules ]
	usage="usage:python2 %prog [-options1 arg1] [-options2 arg2] ..."
	parser=optparse.OptionParser(usage,version="%prog 1.2")

	# input/output dir or file
	parser.add_option('--output', dest = 'output', type = 'string', help = 'the position of the result')
	parser.add_option('--prefix', dest = 'prefix', type = 'string', help = '')
	parser.add_option('--MCI_clinical', dest = 'MCI_clinical', type = 'string', help = '')
	parser.add_option('--AD_clinical', dest = 'AD_clinical', type = 'string', help = '')
	parser.add_option('--MCI_DESeq2_indir', dest = 'MCI_DESeq2_indir', type = 'string', help = '')
	parser.add_option('--AD_DESeq2_indir', dest = 'AD_DESeq2_indir', type = 'string', help = '')
	parser.add_option('--pickle_file', dest = 'pickle_file', type = 'string', help = '')
	parser.add_option('--tumor_name', dest = 'tumor_name', type = 'string', help = '')
	parser.add_option('--UP_DOWN', dest = 'UP_DOWN', type = 'string', help = '')
	parser.add_option('--PC', dest = 'PC', type = 'string', help = '')

	# oject the cmd
	(options,args) = parser.parse_args()

	# [public]
	output = options.output
	MCI_clinical = options.MCI_clinical
	AD_clinical = options.AD_clinical
	prefix = options.prefix
	MCI_DESeq2_indir = options.MCI_DESeq2_indir
	AD_DESeq2_indir = options.AD_DESeq2_indir
	pickle_file = options.pickle_file
	tumor_name = options.tumor_name
	UP_DOWN = options.UP_DOWN
	PC = options.PC

	if output:
		makedir_return = os.path.isdir(output) or os.makedirs(output)

	PC_df = pd.read_csv(PC, sep = "\t", index_col = "Gene")

	MCI_clinical_df = pd.read_csv(MCI_clinical, index_col = "specimenID", sep = "\t")
	MCI_clinical_df = MCI_clinical_df[MCI_clinical_df['sample_type'] == "MCI"]
	MCI_samples = MCI_clinical_df.index.tolist()
		
	AD_clinical_df = pd.read_csv(AD_clinical, index_col = "specimenID", sep = "\t")
	AD_clinical_df = AD_clinical_df[AD_clinical_df['sample_type'] == "AD"]
	AD_samples = AD_clinical_df.index.tolist()

	if os.path.isfile(pickle_file):
		print("have pickle file")
		with open(pickle_file, 'rb') as file:
			samples_dic = pickle.load(file)
	else:
		samples_dic = {}
		total_sample_df = pd.DataFrame()
		sample_ID = []
		total_FC = []
		group = []
		for par, dirs, files in os.walk(MCI_DESeq2_indir):
			for subfile in files:
				if re.search(r"DESeq2.results.xls$", subfile):
					subfile_abspath = par + "/" + subfile
					sample_name = subfile.split(".")[0]
					print(sample_name)
					df = pd.read_csv(subfile_abspath, sep = "\t", index_col = "Gene")
					inter_transcript = list(set(PC_df.index) & set(df.index))
					df = df.loc[inter_transcript]
					df = df[(df['log2FoldChange'] > 0) & (df['pvalue'] < 0.05)]
					for (g, fc, pvalue) in itertools.zip_longest(df.index, df['log2FoldChange'], df['pvalue']):
#						print(g, fc, pvalue)
						samples_dic.setdefault(sample_name, {})
						samples_dic[sample_name].setdefault(g, {})
						samples_dic[sample_name][g].setdefault("logFC", float(fc))
						samples_dic[sample_name][g].setdefault("PValue", float(pvalue))
	
		for par, dirs, files in os.walk(AD_DESeq2_indir):
			for subfile in files:
				if re.search(r"DESeq2.results.xls$", subfile):
					subfile_abspath = par + "/" + subfile
					sample_name = subfile.split(".")[0]
					print(sample_name)
					df = pd.read_csv(subfile_abspath, sep = "\t", index_col = "Gene")
					inter_transcript = list(set(PC_df.index) & set(df.index))
					df = df.loc[inter_transcript]
					df = df[(df['log2FoldChange'] > 0) & (df['pvalue'] < 0.05)]
					for (g, fc, pvalue) in itertools.zip_longest(df.index, df['log2FoldChange'], df['pvalue']):
						samples_dic.setdefault(sample_name, {})
						samples_dic[sample_name].setdefault(g, {})
						samples_dic[sample_name][g].setdefault("logFC", float(fc))
						samples_dic[sample_name][g].setdefault("PValue", float(pvalue))

		pickle_outfile = output + "/" + prefix + ".pkl"
		with open(pickle_outfile, 'wb') as file:
			pickle.dump(samples_dic, file)

	total_sample_df = pd.DataFrame()
	total_FC1 = []
	total_FC2 = []
	pvalue = []
	genes = []
	group = []
	sample_ID = []
	for ss in samples_dic:
		Fit_gs = []
		temp_total_fc = []
		temp_normalize_total_fc = []
		for g in samples_dic.get(ss):
			FC = samples_dic.get(ss).get(g).get("logFC")	
			Pvalue = samples_dic.get(ss).get(g).get("PValue")
			normalize_fc = -FC * math.log(Pvalue + 1e-300)
			genes.append(g)
			sample_ID.append(ss)
			total_FC1.append(FC)
			total_FC2.append(normalize_fc)
			pvalue.append(Pvalue)
			if ss in MCI_samples:
				group.append("MCI")
			if ss in AD_samples:
				group.append("AD")

	total_sample_df["Sample"] = sample_ID
	total_sample_df['logFC'] = total_FC1
	total_sample_df['logFC_normalize'] = total_FC2
	total_sample_df['pvalue'] = pvalue
	total_sample_df['gene'] = genes
	total_sample_df['group'] = group	

	for i in range(0, 100):  # 第一层遍历，0到10之间，间隔为0.01
		temp_fc = i * 0.01  # 将索引转换为实际值
		for j in range(1, 501):  # 第二层遍历，从0.05到0.10，每次递减0.01
			pvalue = j * 0.0001  # 将索引转换为实际值

			total_sample_df1 = total_sample_df[(total_sample_df['pvalue'] < pvalue) & (total_sample_df['logFC'] < temp_fc)]

			# Task 1: Count the rows for each Sample and sort dataframeA
			sample_counts = total_sample_df1['Sample'].value_counts()
			dataframeA = pd.DataFrame({'Sample': sample_counts.index, 'Row Number': sample_counts.values})
			group = []
			for ss in dataframeA["Sample"]:
				if ss in MCI_samples:
					group.append("MCI")
				if ss in AD_samples:
					group.append("AD")
			dataframeA['group'] = group
			dataframeA = dataframeA.sort_values(by='Row Number')
#			print(dataframeA)
			top_M_samples1 = dataframeA.head(len(MCI_samples))
			MCI_count1 = top_M_samples1[top_M_samples1['group'] == 'MCI'].shape[0]
			MCI_percentage1 = MCI_count1 / len(MCI_samples) * 100
#			print(MCI_percentage1)

			# Task 2: Calculate the total logFC for each Sample and sort dataframeB
			sample_total_logFC = total_sample_df1.groupby('Sample')['logFC'].sum()
			dataframeB = pd.DataFrame({'Sample': sample_total_logFC.index, 'Total logFC': sample_total_logFC.values})
			group = []
			for ss in dataframeA["Sample"]:
				if ss in MCI_samples:
					group.append("MCI")
				if ss in AD_samples:
					group.append("AD")
			dataframeB['group'] = group
			dataframeB = dataframeB.sort_values(by='Total logFC')
#			print(dataframeB)
			top_M_samples2 = dataframeB.head(len(MCI_samples))
			MCI_count2 = top_M_samples2[top_M_samples2['group'] == 'MCI'].shape[0]
			MCI_percentage2 = MCI_count2 / len(MCI_samples) * 100
#			print(MCI_percentage)

			# Task 3: Calculate the total logFC_normalize for each Sample and sort dataframeC
			sample_total_logFC_normalize = total_sample_df1.groupby('Sample')['logFC_normalize'].sum()
			dataframeC = pd.DataFrame({'Sample': sample_total_logFC_normalize.index, 'Total logFC_normalize': sample_total_logFC_normalize.values})
			group = []
			for ss in dataframeA["Sample"]:
				if ss in MCI_samples:
					group.append("MCI")
				if ss in AD_samples:
					group.append("AD")
			dataframeC['group'] = group
			dataframeC = dataframeC.sort_values(by='Total logFC_normalize')
#			print(dataframeC)
			top_M_samples3 = dataframeC.head(len(MCI_samples))
			MCI_count3 = top_M_samples3[top_M_samples3['group'] == 'MCI'].shape[0]
			MCI_percentage3 = MCI_count3 / len(MCI_samples) * 100
#			print(MCI_percentage)

			print(MCI_percentage1, MCI_percentage2, MCI_percentage3)
			if MCI_percentage1 > 60 or MCI_percentage2 > 60 or MCI_percentage3 > 60:
				print("FC :", i, "Pvalue :", j)
				sys.exit()


if __name__ == '__main__':
	'''
	'''	
	
	ss_DESeq2()




	
