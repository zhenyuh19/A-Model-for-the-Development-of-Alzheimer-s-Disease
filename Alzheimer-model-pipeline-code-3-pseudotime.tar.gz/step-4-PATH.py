import pandas as pd
import pingouin as pg

# Sample data for A, B, C, and Z
data = {
    'A': [1.0, 1.2, 0.8, 1.1, 1.3],
    'B': [2.5, 2.0, 2.2, 2.3, 2.6],
    'C': [3.0, 2.8, 2.9, 3.1, 2.7],
    'Z': [4.5, 4.8, 4.6, 4.7, 4.4]
}

df = pd.DataFrame(data)

# Perform path analysis
model = 'A -> Z + B -> Z + C -> Z'
result = pg.path_analysis(data=df, model=model)

# Print the path coefficients and p-values
print(result['coef'])
print(result['pval'])

