import pandas as pd
from rpy2.robjects import pandas2ri
from rpy2.robjects.packages import importr
import rpy2.robjects as ro

# Sample data for A, B, C, D, and Z
data = {
    'A': [1, 2, 3, 4, 5],
    'B': [2, 3, 4, 5, 6],
    'C': [3, 4, 5, 6, 7],
    'D': [4, 5, 6, 7, 8],
    'Z': [5, 6, 7, 8, 9]
}

df = pd.DataFrame(data)

# Load the lavaan library from R
lavaan = importr('lavaan')

# Convert pandas DataFrame to an R data frame
pandas2ri.activate()
rdf = pandas2ri.py2rpy(df)

# Define the mediation model: Z ~ A + B + C + D; A -> B; C -> D
mediation_model = '''
Z ~ a*A + b*B + c*C + d*D
B ~ a*A
D ~ c*C
'''

# Fit the mediation model using lavaan
fit = lavaan.lavaan(mediation_model, data=rdf)

# Print the results
print(fit)

