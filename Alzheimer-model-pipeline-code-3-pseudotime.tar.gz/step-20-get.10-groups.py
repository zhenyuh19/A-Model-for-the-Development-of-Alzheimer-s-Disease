#!/python
#-*-coding:utf-8-*-
# 统计

def Wilcox():
	'''
	 
	'''
	import re,getopt,os,sys,optparse,glob,itertools
	import pandas as pd
	import scipy
	import scipy.stats as stats
	import numpy as np

	# [ read cmd by optparse modules ]
	usage="usage:python2 %prog [-options1 arg1] [-options2 arg2] ..."
	parser=optparse.OptionParser(usage,version="%prog 1.2")

	# input/output dir or file
	parser.add_option('--extracellular_acidosis_ssGSEA', dest = 'extracellular_acidosis_ssGSEA', type = 'string', help = '')
	parser.add_option('--ssGSEA', dest = 'ssGSEA', type = 'string', help = '')
	parser.add_option('--tpm', dest = 'tpm', type = 'string', help = '')
	parser.add_option('--MCI_clinical_info', dest = 'MCI_clinical_info', type = 'string', help = '')
	parser.add_option('--AD_clinical_info', dest = 'AD_clinical_info', type = 'string', help = '')
	parser.add_option('--clinical_info', dest = 'clinical_info', type = 'string', help = '')
	parser.add_option('--output', dest = 'output', type = 'string', help = 'the position of the result')
	parser.add_option('--prefix', dest = 'prefix', type = 'string', help = '')
	parser.add_option('--extracellular_acidosis_label', dest = 'extracellular_acidosis_label', type = 'string', help = '')
	parser.add_option('--apoto_label', dest = 'apoto_label', type = 'string', help = '')

	# oject the cmd
	(options,args) = parser.parse_args()

	# [public]
	extracellular_acidosis_ssGSEA = options.extracellular_acidosis_ssGSEA
	ssGSEA = options.ssGSEA
	tpm = options.tpm
	MCI_clinical_info = options.MCI_clinical_info
	AD_clinical_info = options.AD_clinical_info
	clinical_info = options.clinical_info
	output = options.output
	prefix = options.prefix
	extracellular_acidosis_label = options.extracellular_acidosis_label
	apoto_label = options.apoto_label

	clinical_df = pd.read_csv(clinical_info, sep = "\t")
	Normal_samples = clinical_df[clinical_df['sample_type'] == "Normal"]['specimenID'].tolist()

	#	
	windows = ['MIX-0-40', 'MIX-35-75','MIX-70-110','MIX-105-145','MIX-140-180','MIX-175-215','MIX-210-250','MIX-245-285','MIX-280-320','MIX-315-355']
	diff_score = {}
	for par, subdirs, subfiles in os.walk(ssGSEA):
		for sub_ssgsea in subfiles:
			if re.search(r"-ssgsea-normalize.xls", sub_ssgsea) and re.search(r"step-steps.40-overlap5-MIX", par):
				sub_ssgsea_abspath = par + "/" + sub_ssgsea
				sub_ssgsea_df = pd.read_csv(sub_ssgsea_abspath, sep = "\t", index_col = "id")

				Normal_ssgsea_df = sub_ssgsea_df[Normal_samples]
				Normal_ssgsea_mean = Normal_ssgsea_df.mean(1)
#				print(Normal_ssgsea_mean)

				window_samples = list(set(sub_ssgsea_df.columns.tolist()) - set(Normal_samples))
				window_ssgsea_df = sub_ssgsea_df[window_samples]
				window_ssgsea_mean = window_ssgsea_df.mean(1)
#				print(window_ssgsea_mean)

				diff = window_ssgsea_mean - Normal_ssgsea_mean

				block = os.path.basename(par)
				MCI_AD = sub_ssgsea.split("-")[0]
				window_name = MCI_AD + "-" + block
				
#				print(diff)

				for index in diff.index:
					diff_score.setdefault(index, {})
#					print(index, diff.loc[index])
					diff_score[index].setdefault(window_name, diff.loc[index])

	total_diff_df = pd.DataFrame()
	func_lst = []
	group = []
	index = []
	for func in diff_score:
		print("\n")
		for sub_wind in windows:
			print(func, " = ", diff_score.get(func).get(sub_wind))
			func_lst.append(diff_score.get(func).get(sub_wind))
			group.append(func)
			index.append(sub_wind)

	total_diff_df["diff"] = func_lst
	total_diff_df["group"] = group

	total_diff_df.index = index
	total_diff_outfile = output + "/" + prefix + ".xls"
	total_diff_df.to_csv(total_diff_outfile, sep = "\t", index_label = "windows")
	


if __name__ == '__main__':
	'''
	'''	
	
	Wilcox()

