python step-2-rank.py step-1-ss-MCI  MCI  ALL

python step-2-rank.py  step-1-ss-AD  AD   ALL

python step-2-rank.py  step-1-ss-Normal  Normal   ALL


python step-2-rank.py step-1-ss-MCI  MCI  UP

python step-2-rank.py  step-1-ss-AD  AD  UP


python step-2-rank.py step-1-ss-MCI  MCI  DOWN

python step-2-rank.py  step-1-ss-AD  AD  DOWN


