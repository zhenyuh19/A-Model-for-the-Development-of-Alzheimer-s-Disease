python3 step-4-get.Apoptotic-2-Amyloid_Extracellular.Acidosis_Intracellular.pH.Elevation_Tau.py \
	--clinical_info /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-3-all-eggnog/step-5-DESeq2-1.3fc-0.05p/MCI_vs_Normal/MCI_vs_Normal.Clinical.Info.xls \
	--ssGSEA /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-6-pseudotime \
	--output /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-6-pseudotime/step-4-Apoptotic-2-Amyloid_Extracellular.Acidosis_Intracellular.pH.Elevation_Tau \
	--check_cmb execution_phase_of_apoptosis-amyloid-beta.formation-ASIC-intracellular.pH.elevation-tau_protein_binding
