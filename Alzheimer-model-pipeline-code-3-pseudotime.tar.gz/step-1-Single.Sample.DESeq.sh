python3  step-1-Single.Sample.DESeq.py \
	--count /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-3-all-eggnog/step-5-DESeq2-1.3fc-0.05p/MCI_vs_Normal/MCI_vs_Normal.transcript.stringtie.Count.xls \
	--clinical /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-3-all-eggnog/step-5-DESeq2-1.3fc-0.05p/MCI_vs_Normal/MCI_vs_Normal.Clinical.Info.xls \
	--output /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-6-pseudotime-FR-vs-7events/step-1-ss-MCI


python3  step-1-Single.Sample.DESeq.py \
	--count /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-3-all-eggnog/step-5-DESeq2-1.3fc-0.05p/AD_vs_Normal/AD_vs_Normal.transcript.stringtie.Count.xls \
	--clinical /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-3-all-eggnog/step-5-DESeq2-1.3fc-0.05p/AD_vs_Normal/AD_vs_Normal.Clinical.Info.xls \
	--output /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-6-pseudotime-FR-vs-7events/step-1-ss-AD 
