python3  step-6-Neuron_death_vs_4Events.non-median.py \
	--Pseudotime_indir /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-6-pseudotime-FR-vs-7events/step-2-rank-for-pseudotime/ \
	--MCI_Extracellular_acidity_2Events /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-3-all-eggnog/step-5-DESeq2-1.3fc-0.05p/Conclusion.MCI-AD/SEM_RSEMA-0.06__CFI-0.95-nonfilter/1-Paper-Aβ.Tau_/Paper-Fig-temp/40-Fenton.reaction.Level-regress-mito.pH_GLS_UCPs_acid.loading_endosomal.pH_lysosomal.pH_apopptosis_ASIC/Neuron_death-vs-4events-MCI.xls \
	--AD_Extracellular_acidity_2Events /home/hcy/Alzheimer/ROSMAP/Dorsolateral.Prefrontal.Cortex/step-Sup-3-all-eggnog/step-5-DESeq2-1.3fc-0.05p/Conclusion.MCI-AD/SEM_RSEMA-0.06__CFI-0.95-nonfilter/1-Paper-Aβ.Tau_/Paper-Fig-temp/40-Fenton.reaction.Level-regress-mito.pH_GLS_UCPs_acid.loading_endosomal.pH_lysosomal.pH_apopptosis_ASIC/Neuron_death-vs-4events-AD.xls \
	--output step-6-rank-non-median
