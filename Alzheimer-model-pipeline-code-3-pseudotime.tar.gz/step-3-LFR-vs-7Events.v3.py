#!/python
#-*-coding:utf-8-*-
# 统计

def Pseudotime():
	'''
	 
	'''
	import re,getopt,os,sys,optparse,glob,itertools
	import pandas as pd
	import scipy
	import scipy.stats as stats
	import statsmodels.api as sm
	import numpy as np

	# [ read cmd by optparse modules ]
	usage="usage:python2 %prog [-options1 arg1] [-options2 arg2] ..."
	parser=optparse.OptionParser(usage,version="%prog 1.2")

	# input/output dir or file
	parser.add_option('--extracellular_acidosis_MCI_LFR_7Events', dest = 'extracellular_acidosis_MCI_LFR_7Events', type = 'string', help = '')
	parser.add_option('--MCI_LFR_7Events', dest = 'MCI_LFR_7Events', type = 'string', help = '')
	parser.add_option('--AD_LFR_7Events', dest = 'AD_LFR_7Events', type = 'string', help = '')
	parser.add_option('--MCI_clinical_info', dest = 'MCI_clinical_info', type = 'string', help = '')
	parser.add_option('--AD_clinical_info', dest = 'AD_clinical_info', type = 'string', help = '')
	parser.add_option('--clinical_info', dest = 'clinical_info', type = 'string', help = '')
	parser.add_option('--output', dest = 'output', type = 'string', help = 'the position of the result')
	parser.add_option('--prefix', dest = 'prefix', type = 'string', help = '')
	parser.add_option('--Pseudotime', dest = 'Pseudotime', type = 'string', help = '')
	parser.add_option('--Pseudotime_indir', dest = 'Pseudotime_indir', type = 'string', help = '')

	# oject the cmd
	(options,args) = parser.parse_args()

	# [public]
	extracellular_acidosis_MCI_LFR_7Events = options.extracellular_acidosis_MCI_LFR_7Events
	MCI_LFR_7Events = options.MCI_LFR_7Events
	AD_LFR_7Events = options.AD_LFR_7Events
	MCI_clinical_info = options.MCI_clinical_info
	AD_clinical_info = options.AD_clinical_info
	clinical_info = options.clinical_info
	output = options.output
	prefix = options.prefix
	Pseudotime = options.Pseudotime
	Pseudotime_indir = options.Pseudotime_indir

	# 读取包含9列信息的文件
	MCI_score_data = pd.read_csv(MCI_LFR_7Events, index_col = "Sample", sep = "\t")
	AD_score_data = pd.read_csv(AD_LFR_7Events, index_col = "Sample", sep = "\t")
	AD_score_data = AD_score_data[MCI_score_data.columns]
	score_data = MCI_score_data.append(AD_score_data)

	# 设定bin的大小和步长
	bin_size = 40
	step_size = 10
	
	# 初始化一个DataFrame来存储结果
	results = pd.DataFrame(columns=['bin', "transporters", "GLS", "UCP", "Tau_formation", "Intracellular_pH_elevation", "Endosomal_pH", "Lysosomal_pH"])
	
	# 创建函数来计算多元回归模型的BIC值
	def calculate_BIC(X, y):
#		model = sm.OLS(y, sm.add_constant(X)).fit()
		model = sm.OLS(y, X).fit()
		BIC = model.bic
		return BIC
	
	# 遍历时间序列文件目录
	output_directory = output
	if not os.path.exists(output_directory):
		os.makedirs(output_directory)
	
	# 初始化之前的斜率和斜率列表
	prev_gls_slope = None
	prev_tau_slope = None
	gls_slopes = []
	tau_slopes = []
	transporters_slopes = []
	UCP_slopes = []
	Intracellular_pH_elevation_slopes = []	
	Endosomal_pH_slopes = []
	Lysosomal_pH_slopes = []

	# 初始化结果存储的DataFrame
	results = pd.DataFrame(columns=['bin', "transporters", "GLS", "UCP", "Tau_formation", "Intracellular_pH_elevation", "Endosomal_pH", "Lysosomal_pH"])

	time_series_directory = Pseudotime_indir	
	# 遍历时间序列文件目录
	for time_series_file in os.listdir(time_series_directory):
		time_series_data = pd.read_csv(os.path.join(time_series_directory, time_series_file), sep="\t")
		score_data2 = score_data.loc[time_series_data['Sample']]

		transporters_contributions = []	
		gls_contributions = []
		tau_contributions = []
		UCP_contributions = []
		Intracellular_pH_elevation_contributions = []
		Endosomal_pH_contributions = []
		Lysosomal_pH_contributions = []
		FR = []

		for bin_start in range(0, len(time_series_data), step_size):
			bin_end = bin_start + bin_size
	
			if bin_end > len(time_series_data):
				break
	
			bin_group = time_series_data.iloc[bin_start:bin_end]
			X = score_data2.loc[bin_group['Sample'], ["transporters", "GLS", "UCP", "Tau_formation", "Intracellular_pH_elevation", "Endosomal_pH", "Lysosomal_pH"]]
			y = score_data2.loc[bin_group['Sample'], ['LFR']]
			FR.append(float(y.mean()))
	
			A_BIC = calculate_BIC(X, y)
			variable_contributions = []
	
			for variable in X.columns:
				X_temp = X.drop(variable, axis=1)
				B_BIC = calculate_BIC(X_temp, y)
				contribution = B_BIC - A_BIC
				variable_contributions.append((variable, contribution))
				if variable == "GLS":
					gls_contributions.append(contribution)

				if variable == "Tau_formation":	
					tau_contributions.append(contribution)

				if variable == "transporters":
					transporters_contributions.append(contribution)

				if variable == "UCP":
					UCP_contributions.append(contribution)

				if variable == "Intracellular_pH_elevation":
					Intracellular_pH_elevation_contributions.append(contribution)

				if variable == "Endosomal_pH":
					Endosomal_pH_contributions.append(contribution)

				if variable == "Lysosomal_pH":
					Lysosomal_pH_contributions.append(contribution)

		# 初始化斜率
		gls_slope = None
		tau_slope = None
	
		# 如果有足够的数据点，计算GLS和Tau_formation的斜率

		if len(transporters_contributions) > 1:
			transporters_slope = np.polyfit(range(len(transporters_contributions)), transporters_contributions, 1)[0]
#			print(gls_slope)
#			transporters_slopes.append(transporters_slope)
		if len(gls_contributions) > 1:
			gls_slope = np.polyfit(range(len(gls_contributions)), gls_contributions, 1)[0]
#			print(gls_slope)
#			gls_slopes.append(gls_slope)
		if len(tau_contributions) > 1:
			tau_slope = np.polyfit(range(len(tau_contributions)), tau_contributions, 1)[0]
#			print(tau_slope)
#			tau_slopes.append(tau_slope)
		if len(UCP_contributions) > 1:
			UCP_slope = np.polyfit(range(len(UCP_contributions)), UCP_contributions, 1)[0]
#			print(gls_slope)
#			UCP_slopes.append(UCP_slope)
		if len(Intracellular_pH_elevation_contributions) > 1:
			Intracellular_pH_elevation_slope = np.polyfit(range(len(Intracellular_pH_elevation_contributions)), Intracellular_pH_elevation_contributions, 1)[0]
#			print(gls_slope)
#			Intracellular_pH_elevation_slopes.append(Intracellular_pH_elevation_slope)
		if len(Endosomal_pH_contributions) > 1:
			Endosomal_pH_slope = np.polyfit(range(len(Endosomal_pH_contributions)), Endosomal_pH_contributions, 1)[0]
#			print(Endosomal_pH_slope)
#			Endosomal_pH_slopes.append(Endosomal_pH_slope)
		if len(Lysosomal_pH_contributions) > 1:
			Lysosomal_pH_slope = np.polyfit(range(len(Lysosomal_pH_contributions)), Lysosomal_pH_contributions, 1)[0]
#			print(Lysosomal_pH_slope)
#			Lysosomal_pH_slopes.append(Lysosomal_pH_slope)
	
		# 检查斜率条件
		if gls_slope > 0 and tau_slope > 0 and UCP_slope < 0 and Intracellular_pH_elevation_slope > 0:
			print(time_series_file.split(".xls")[0] + "-LFR-7Events.xls", "gls_slope : ", gls_slope, " tau_slope : ", tau_slope, "UCP_slopes : ", UCP_slope, " Intracellular_pH_elevation_slopes : ", Intracellular_pH_elevation_slope)
			results_df = pd.DataFrame()
			results_df['transporters'] = transporters_contributions
			results_df['GLS'] = gls_contributions
			results_df['UCP'] = UCP_contributions
			results_df['Tau_formation'] = tau_contributions
			results_df['Intracellular_pH_elevation'] = Intracellular_pH_elevation_contributions
			results_df['Endosomal_pH'] = Endosomal_pH_contributions
			results_df['Lysosomal_pH'] = Lysosomal_pH_contributions
			results_df['FR'] = FR

			# 保存满足条件的结果
			results_df.to_csv(os.path.join(output_directory, time_series_file.split(".xls")[0] + "-LFR-7Events.xls"), index_label = "Time", sep = "\t")
	


	
if __name__ == '__main__':
	'''
	'''	
	
	Pseudotime()

